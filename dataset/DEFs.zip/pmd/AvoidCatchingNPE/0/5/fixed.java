public class foo {
  public void testOr_nullSupplier_absent() {
    Supplier<Object> nullSupplier = (Supplier<Object>) Suppliers.<@Nullable Object>ofInstance(null);
    Optional<Object> absentOptional = Optional.absent();
    assertThrows(NullPointerException.class, () -> absentOptional.or(nullSupplier));
  }
}