public class foo {
    private synchronized void checkConnectionStatus() {
        try {
            CompletableFuture<Watcher.Event.KeeperState> future = new CompletableFuture<>();
            zk.exists("/", false, (StatCallback) (rc, path, ctx, stat) -> {
                switch (KeeperException.Code.get(rc)) {
                case CONNECTIONLOSS:
                    future.complete(Watcher.Event.KeeperState.Disconnected);
                    break;

                case SESSIONEXPIRED:
                    future.complete(Watcher.Event.KeeperState.Expired);
                    break;

                case OK:
                default:
                    future.complete(Watcher.Event.KeeperState.SyncConnected);
                }
            }, null);

            Watcher.Event.KeeperState zkClientState;
            try {
                zkClientState = future.get(tickTimeMillis, TimeUnit.MILLISECONDS);
            } catch (TimeoutException e) {
                // Consider zk disconnection if zk operation takes more than TICK_TIME
                zkClientState = Watcher.Event.KeeperState.Disconnected;
            }

            checkState(zkClientState);
        } catch (RejectedExecutionException | InterruptedException e) {
            task.cancel(true);
        } catch (Throwable t) {
            log.warn("Error while checking ZK connection status", t);
        }
    }
}