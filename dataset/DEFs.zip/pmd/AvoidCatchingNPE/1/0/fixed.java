public class foo {
  public void testStrong_null() {
    Interner<String> pool = Interners.newStrongInterner();
    assertThrows(NullPointerException.class, () -> pool.intern(null));
  }
}