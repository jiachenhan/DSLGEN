public class foo {
  public void testNullMonitorInGuardConstructorThrowsNPE() {
    assertThrows(NullPointerException.class, () -> new FlagGuard(null));
  }
}