public class foo {
    public ECDSASignatureTest() {

        // This test fails with the IBM JDK
        if (isJavaVendor("IBM")) {
            ibmJDK = true;
        }

        // see if we can load the keystore et all
        try {
            KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            InputStream in = ECDSASignatureTest.class.getResourceAsStream("/org/apache/camel/component/crypto/ecdsa.jks");
            keyStore.load(in, "security".toCharArray());
            privateKey = (PrivateKey) keyStore.getKey("ECDSA", "security".toCharArray());
            x509 = (X509Certificate) keyStore.getCertificate("ECDSA");
        } catch (Exception e) {
            LOG.warn("Cannot setup keystore for running this test due {}. This test is skipped.", e.getMessage(), e);
            canRun = false;
        }
    }
}