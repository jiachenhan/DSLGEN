public class foo {
  public void testNewWriter() throws IOException {
    File temp = createTempFile();
    assertThrows(NullPointerException.class, () -> Files.newWriter(temp, null));

    assertThrows(NullPointerException.class, () -> Files.newWriter(null, Charsets.UTF_8));

    BufferedWriter w = Files.newWriter(temp, Charsets.UTF_8);
    try {
      w.write(I18N);
    } finally {
      w.close();
    }

    File i18nFile = getTestFile("i18n.txt");
    assertTrue(Files.equal(i18nFile, temp));
  }
}