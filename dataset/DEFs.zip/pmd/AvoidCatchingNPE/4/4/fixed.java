public class foo {
  public void testValues_nullToArray() {
    for (LoadingCache<Object, Object> cache : caches()) {
      Collection<Object> values = cache.asMap().values();
      assertThrows(NullPointerException.class, () -> values.toArray((Object[]) null));
      checkEmpty(cache);
    }
  }
}