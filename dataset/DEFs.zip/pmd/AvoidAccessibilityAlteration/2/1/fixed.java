public class foo {
    @After
    public void tearDown() throws Exception {
        ContextPreInitializationTestFirstLanguage.callDependentLanguage = false;
        ContextPreInitializationTestSecondLanguage.callDependentLanguageInCreate = false;
        ContextPreInitializationTestSecondLanguage.callDependentLanguageInPatch = false;
        ContextPreInitializationTestSecondLanguage.lookupService = false;
        ContextPreInitializationFirstInstrument.actions = null;
        BaseLanguage.actions.clear();
        resetSystemPropertiesOptions();
        resetLanguageHomes();
        patchableLanguages.clear();
        emittedContexts.clear();
        NEXT_ORDER_INDEX.set(0);

        final Class<?> holderClz = Class.forName("org.graalvm.polyglot.Engine$ImplHolder", true, ContextPreInitializationTest.class.getClassLoader());
        final Method preInitMethod = holderClz.getDeclaredMethod("resetPreInitializedEngine");
        ReflectionUtils.setAccessible(preInitMethod, true);
        preInitMethod.invoke(null);
    }
}