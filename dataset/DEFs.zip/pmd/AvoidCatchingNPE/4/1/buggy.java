public class foo {
  /** constructor with null array throws NPE */
  public void testConstructor2NPE() {
    double[] a = null;
    try {
      new AtomicDoubleArray(a);
      fail();
    } catch (NullPointerException success) {
    }
  }
}