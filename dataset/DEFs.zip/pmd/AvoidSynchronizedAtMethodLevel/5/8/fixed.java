public class foo {
	public void unloadAttributes() {
		if (attributes.isEmpty()) {
			return;
		}
		synchronized (this) {
			attributes.entrySet().removeIf(entry -> !entry.getValue().keepLoaded());
		}
	}
}