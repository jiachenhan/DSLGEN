public class foo {
    @Test
    public void testModifyColumnsWithAMV1() {
        try {
            checkModifyColumnsWithMaterializedViews(starRocksAssert,
                    "create materialized view mv1 distributed by random refresh deferred manual " +
                            "as select timestamp, count(error_code) from sc_dup3 " +
                            "where op_id > 10 group by timestamp",
                    "alter table sc_dup3 drop column op_id",
                    false);
            MaterializedView mv = (MaterializedView) starRocksAssert.getTable("test", "mv1");
            Assert.assertFalse(mv.isActive());
            Assert.assertTrue(mv.getInactiveReason().contains("base table schema changed for columns: op_id"));
        } catch (Exception e) {
            Assert.fail();
        } finally {
            try {
                starRocksAssert.dropMaterializedView("mv1");
            } catch (Exception e) {
                // ignore
            }
        }
    }
}