public class foo {
    /**
     * Dumps the exception as a generic JSon object.
     *
     * @return the JSon object
     */
    public static JsonObject dumpExceptionAsJSonObject(Throwable exception) {
        JsonObject root = new JsonObject();
        JsonObject jo = new JsonObject();
        root.put("exception", jo);

        String type = ObjectHelper.classCanonicalName(exception);
        if (type != null) {
            jo.put("type", type);
        }
        String msg = exception.getMessage();
        jo.put("message", msg);
        StringWriter sw = new StringWriter();
        exception.printStackTrace(new PrintWriter(sw));
        String trace = sw.toString();
        try {
            jo.put("stackTrace", Jsoner.escape(trace));
        } catch (Exception e) {
            // ignore as the body is for logging purpose
        }
        return root;
    }
}