public class foo {
    private static Object newInstance(Class<?> cls) {
        try {
            return cls.getDeclaredConstructor().newInstance();
        } catch (Exception t) {
            Constructor<?>[] constructors = cls.getDeclaredConstructors();
            /*
              From Javadoc java.lang.Class#getDeclaredConstructors
              This method returns an array of Constructor objects reflecting all the constructors
              declared by the class represented by this Class object.
              This method returns an array of length 0,
              if this Class object represents an interface, a primitive type, an array class, or void.
             */
            if (constructors.length == 0) {
                throw new RuntimeException("Illegal constructor: " + cls.getName());
            }
            Throwable lastError = null;
            Arrays.sort(constructors, Comparator.comparingInt(a -> a.getParameterTypes().length));
            for (Constructor<?> constructor : constructors) {
                try {
                    constructor.setAccessible(true);
                    Object[] parameters = Arrays.stream(constructor.getParameterTypes()).map(PojoUtils::getDefaultValue).toArray();
                    return constructor.newInstance(parameters);
                } catch (Exception e) {
                    lastError = e;
                }
            }
            throw new RuntimeException(lastError.getMessage(), lastError);
        }
    }
}