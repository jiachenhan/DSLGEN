public class foo {
  public void testEntrySet_nullToArray() {
    for (LoadingCache<Object, Object> cache : caches()) {
      Set<Entry<Object, Object>> entries = cache.asMap().entrySet();
      assertThrows(
          NullPointerException.class, () -> entries.toArray((Entry<Object, Object>[]) null));
      checkEmpty(cache);
    }
  }
}