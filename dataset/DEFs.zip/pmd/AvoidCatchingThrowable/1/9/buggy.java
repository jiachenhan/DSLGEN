public class foo {
    private static LRUCacheFactory createLRUCacheFactory() {
        LOG.trace("createLRUCacheFactory");
        try {
            ClassLoader classLoader = LRUCacheFactory.class.getClassLoader();
            URL url = classLoader.getResource("META-INF/services/org/apache/camel/" + FACTORY);
            if (url != null) {
                Properties props = new Properties();
                try (InputStream is = url.openStream()) {
                    props.load(is);
                }
                String clazzName = props.getProperty("class");
                if (clazzName != null) {
                    LOG.trace("Loading class: {}", clazzName);
                    Class<?> clazz = classLoader.loadClass(clazzName);
                    LOG.trace("Creating LRUCacheFactory instance from class: {}", clazzName);
                    Object factory = clazz.getDeclaredConstructor().newInstance();
                    LOG.trace("Created LRUCacheFactory instance: {}", factory);
                    LOG.info("Detected and using LRUCacheFactory: {}", factory);
                    return (LRUCacheFactory) factory;
                }
            }
        } catch (Throwable t) {
            LOG.warn("Error creating LRUCacheFactory. Will use DefaultLRUCacheFactory.", t);
        }
        // use default
        LOG.debug("Creating DefaultLRUCacheFactory");
        return new DefaultLRUCacheFactory();
    }
}