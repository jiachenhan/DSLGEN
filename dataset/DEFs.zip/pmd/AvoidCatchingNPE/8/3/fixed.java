public class foo {
  public void testFromByteArray_withNullInputThrowsNullPointerException() {
    assertThrows(NullPointerException.class, () -> Stats.fromByteArray(null));
  }
}