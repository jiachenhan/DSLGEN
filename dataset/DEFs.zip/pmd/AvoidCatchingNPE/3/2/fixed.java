public class foo {
  public void testFirstNonNull_throwsNullPointerException() {
    assertThrows(NullPointerException.class, () -> MoreObjects.firstNonNull(null, null));
  }
}