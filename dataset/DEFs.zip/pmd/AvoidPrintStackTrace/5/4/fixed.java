public class foo {
  @SuppressWarnings({"squid:S3776"}) // Suppress high Cognitive Complexity warning
  private static int executeQuery(IoTDBConnection connection, String cmd) {
    int executeStatus = CODE_OK;
    long startTime = System.currentTimeMillis();
    try (Statement statement = connection.createStatement()) {
      ZoneId zoneId = ZoneId.of(connection.getTimeZone());
      statement.setFetchSize(fetchSize);
      boolean hasResultSet = statement.execute(cmd.trim());
      if (hasResultSet) {
        // print the result
        try (ResultSet resultSet = statement.getResultSet()) {
          ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
          int columnLength = resultSetMetaData.getColumnCount();
          List<Integer> maxSizeList = new ArrayList<>(columnLength);
          List<List<String>> lists =
              cacheResult(resultSet, maxSizeList, columnLength, resultSetMetaData, zoneId);
          output(lists, maxSizeList);
          long costTime = System.currentTimeMillis() - startTime;
          println(String.format("It costs %.3fs", costTime / 1000.0));
          while (!isReachEnd) {
            if (continuePrint) {
              maxSizeList = new ArrayList<>(columnLength);
              lists = cacheResult(resultSet, maxSizeList, columnLength, resultSetMetaData, zoneId);
              output(lists, maxSizeList);
              continue;
            }
            println(
                String.format(
                    "Reach the max_display_num = %s. Press ENTER to show more, input 'q' to quit.",
                    maxPrintRowCount));
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            try {
              if ("".equals(br.readLine())) {
                maxSizeList = new ArrayList<>(columnLength);
                lists =
                    cacheResult(resultSet, maxSizeList, columnLength, resultSetMetaData, zoneId);
                output(lists, maxSizeList);
              } else {
                break;
              }
            } catch (IOException e) {
              IoTPrinter.printException(e);
              executeStatus = CODE_ERROR;
            }
          }
          // output tracing activity
          if (((IoTDBJDBCResultSet) resultSet).isSetTracingInfo()) {
            maxSizeList = new ArrayList<>(2);
            lists = cacheTracingInfo(resultSet, maxSizeList);
            outputTracingInfo(lists, maxSizeList);
          }
        }
      } else {
        println("Msg: " + SUCCESS_MESSAGE);
      }
    } catch (Exception e) {
      println("Msg: " + e.getMessage());
      executeStatus = CODE_ERROR;
    } finally {
      resetArgs();
    }
    return executeStatus;
  }
}