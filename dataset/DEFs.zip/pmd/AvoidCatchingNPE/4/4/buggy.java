public class foo {
  public void testValues_nullToArray() {
    for (LoadingCache<Object, Object> cache : caches()) {
      Collection<Object> values = cache.asMap().values();
      try {
        values.toArray((Object[]) null);
        fail();
      } catch (NullPointerException expected) {
      }
      checkEmpty(cache);
    }
  }
}