public class foo {
        synchronized void sendMsg(TbWebSocketMsg<?> msg) {
            if (isSending.compareAndSet(false, true)) {
                sendMsgInternal(msg);
            } else {
                try {
                    msgQueue.add(msg);
                } catch (RuntimeException e) {
                    if (log.isTraceEnabled()) {
                        log.trace("[{}][{}] Session closed due to queue error", sessionRef.getSecurityCtx().getTenantId(), session.getId(), e);
                    } else {
                        log.info("[{}][{}] Session closed due to queue error", sessionRef.getSecurityCtx().getTenantId(), session.getId());
                    }
                    closeSession(CloseStatus.POLICY_VIOLATION.withReason("Max pending updates limit reached!"));
                }
            }
        }
}