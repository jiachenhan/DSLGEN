public class foo {
    private void checkNetworkAccessible() throws DBException {
        try {
            WebUtils.openConnection(NETWORK_TEST_URL, GeneralUtils.getProductTitle());
        } catch (IOException e) {
            String message;
            if (RuntimeUtils.isWindows() && e instanceof SSLHandshakeException) {
                if (DBWorkbench.getPlatform()
                    .getApplication().hasProductFeature(DBConnectionConstants.PRODUCT_FEATURE_SIMPLE_TRUSTSTORE)) {
                    message = UIConnectionMessages.dialog_driver_download_network_unavailable_cert_msg;
                } else {
                    message = UIConnectionMessages.dialog_driver_download_network_unavailable_cert_msg_advanced;
                }
            } else {
                message = UIConnectionMessages.dialog_driver_download_network_unavailable_msg;
            }
            String exceptionMessage = message + "\n" + e.getClass().getName() + ":" + e.getMessage();
            throw new DBException(exceptionMessage);
        }
    }
}