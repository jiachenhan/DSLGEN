public class foo {
        synchronized void exit() {
            updateKillState(EXITING);
        }
}