public class foo {
  /**
   * Transfer queued {@link Event}s which are waiting for retry.
   *
   * @throws Exception if an error occurs. The error will be handled by pipe framework, which will
   *     retry the {@link Event} and mark the {@link Event} as failure and stop the pipe if the
   *     retry times exceeds the threshold.
   * @see PipeConnector#transfer(Event) for more details.
   * @see PipeConnector#transfer(TabletInsertionEvent) for more details.
   * @see PipeConnector#transfer(TsFileInsertionEvent) for more details.
   */
  private synchronized void transferQueuedEventsIfNecessary() throws Exception {
    while (!retryEventQueue.isEmpty()) {
      final Event peekedEvent = retryEventQueue.peek();

      if (peekedEvent instanceof PipeInsertNodeTabletInsertionEvent) {
        retryConnector.transfer((PipeInsertNodeTabletInsertionEvent) peekedEvent);
      } else if (peekedEvent instanceof PipeRawTabletInsertionEvent) {
        retryConnector.transfer((PipeRawTabletInsertionEvent) peekedEvent);
      } else if (peekedEvent instanceof PipeTsFileInsertionEvent) {
        // Using the async connector to transfer the event for performance.
        transferWithoutCheck((PipeTsFileInsertionEvent) peekedEvent);
      } else {
        LOGGER.warn(
            "IoTDBThriftAsyncConnector does not support transfer generic event: {}.", peekedEvent);
      }

      if (peekedEvent instanceof EnrichedEvent) {
        ((EnrichedEvent) peekedEvent)
            .decreaseReferenceCount(IoTDBDataRegionAsyncConnector.class.getName(), true);
      }

      final Event polledEvent = retryEventQueue.poll();
      if (polledEvent != peekedEvent) {
        LOGGER.error(
            "The event polled from the queue is not the same as the event peeked from the queue. "
                + "Peeked event: {}, polled event: {}.",
            peekedEvent,
            polledEvent);
      }
      if (polledEvent != null && LOGGER.isDebugEnabled()) {
        LOGGER.debug("Polled event {} from retry queue.", polledEvent);
      }
    }
  }
}