public class foo {
  public static void main(String[] args) {
    try {
      String path = "Record.tsfile";
      File f = FSFactoryProducer.getFSFactory().getFile(path);
      if (f.exists()) {
        f.delete();
      }

      try (TsFileWriter tsFileWriter = new TsFileWriter(f)) {
        List<MeasurementSchema> schemas = new ArrayList<>();
        schemas.add(new MeasurementSchema(SENSOR_1, TSDataType.INT64, TSEncoding.RLE));
        schemas.add(new MeasurementSchema(SENSOR_2, TSDataType.INT64, TSEncoding.RLE));
        schemas.add(new MeasurementSchema(SENSOR_3, TSDataType.INT64, TSEncoding.RLE));

        // register timeseries
        tsFileWriter.registerTimeseries(new Path(DEVICE_1), schemas);

        List<IMeasurementSchema> writeMeasurementScheams = new ArrayList<>();
        // example1
        writeMeasurementScheams.add(schemas.get(0));
        writeMeasurementScheams.add(schemas.get(1));
        writeMeasurementScheams.add(schemas.get(2));
        write(tsFileWriter, DEVICE_1, writeMeasurementScheams, 10000, 0, 0);
      }
    } catch (Throwable e) {
      e.printStackTrace();
      System.out.println(e.getMessage());
    }
  }
}