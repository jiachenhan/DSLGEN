public class foo {
  /** Returns whether a key exists in Android Keystore. */
  boolean hasKey(String keyUri) throws GeneralSecurityException {
    String keyId = Validators.validateKmsKeyUriAndRemovePrefix(PREFIX, keyUri);
    try {
      synchronized (keystoreLock) {
        return getAndroidKeyStore().containsAlias(keyId);
      }
    } catch (NullPointerException ex1) {
      Log.w(TAG, "Keystore is temporarily unavailable, wait, reinitialize Keystore and try again.");
      sleepRandomAmount();
      synchronized (keystoreLock) {
        return getAndroidKeyStore().containsAlias(keyId);
      }
    }
  }
}