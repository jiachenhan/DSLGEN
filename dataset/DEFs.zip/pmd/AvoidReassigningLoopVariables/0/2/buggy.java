public class foo {
    private void analyzePeriodically() {
        try {
            AnalysisManager analysisManager = Env.getCurrentEnv().getAnalysisManager();
            List<AnalysisInfo> jobInfos = analysisManager.findPeriodicJobs();
            for (AnalysisInfo jobInfo : jobInfos) {
                jobInfo = new AnalysisInfoBuilder(jobInfo).setJobType(JobType.SYSTEM).build();
                createSystemAnalysisJob(jobInfo);
            }
        } catch (DdlException e) {
            LOG.warn("Failed to periodically analyze the statistics." + e);
        }
    }
}