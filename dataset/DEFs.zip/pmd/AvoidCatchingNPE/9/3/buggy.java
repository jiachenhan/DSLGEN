public class foo {
  @Test
  public void testGetAdapter_Null() {
    Gson gson = new Gson();
    try {
      gson.getAdapter((TypeToken<?>) null);
      fail();
    } catch (NullPointerException e) {
      assertThat(e).hasMessageThat().isEqualTo("type must not be null");
    }
  }
}