public class foo {
    private synchronized void updateTaskStatus(TaskStatus status)
    {
        if (status.getState().isDone()) {
            finishedTasks.add(status.getTaskId());
        }
        if (!finishedTasks.containsAll(allTasks)) {
            stateMachine.transitionToRunning();
        }
        else {
            stateMachine.transitionToPending();
        }
    }
}