public class foo {
    private synchronized void triggerRedelivery(Timeout t) {
        if (nackedMessages.isEmpty()) {
            this.timeout = null;
            return;
        }

        // Group all the nacked messages into one single re-delivery request
        Set<MessageId> messagesToRedeliver = new HashSet<>();
        long now = System.nanoTime();
        nackedMessages.forEach((ledgerId, entryId, partitionIndex, timestamp) -> {
            if (timestamp < now) {
                MessageId msgId = new MessageIdImpl(ledgerId, entryId,
                        // need to covert non-partitioned topic partition index to -1
                        (int) (partitionIndex == NON_PARTITIONED_TOPIC_PARTITION_INDEX ? -1 : partitionIndex));
                addChunkedMessageIdsAndRemoveFromSequenceMap(msgId, messagesToRedeliver, this.consumer);
                messagesToRedeliver.add(msgId);
            }
        });

        if (!messagesToRedeliver.isEmpty()) {
            for (MessageId messageId : messagesToRedeliver) {
                nackedMessages.remove(((MessageIdImpl) messageId).getLedgerId(),
                        ((MessageIdImpl) messageId).getEntryId());
            }
            consumer.onNegativeAcksSend(messagesToRedeliver);
            log.info("[{}] {} messages will be re-delivered", consumer, messagesToRedeliver.size());
            consumer.redeliverUnacknowledgedMessages(messagesToRedeliver);
        }

        this.timeout = timer.newTimeout(this::triggerRedelivery, timerIntervalNanos, TimeUnit.NANOSECONDS);
    }
}