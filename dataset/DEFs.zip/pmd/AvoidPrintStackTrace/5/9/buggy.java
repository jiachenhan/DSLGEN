public class foo {
    private List<Record> loadIcebergTable() {
        List<Record> results = new ArrayList<>();
        IcebergTableLoader tableLoader = getTableLoader();
        try {
            Table table = tableLoader.loadTable();
            try (CloseableIterable<Record> records = IcebergGenerics.read(table).build()) {
                for (Record record : records) {
                    results.add(record);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return results;
    }
}