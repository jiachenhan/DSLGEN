public class foo {
        boolean executeFromQueue() {
            final Runnable polled = queue != null ? queue.pollFirst() : null;
            if (polled == null) {
                return false;
            }
            try {
                if (stats) {
                    executor.pendingTasks.decrement();
                }
                if (LOG.isTraceEnabled()) {
                    LOG.trace("Running: {}", polled);
                }
                polled.run();
            } catch (Exception t) {
                // should not happen
                LOG.warn("Error executing reactive work due to {}. This exception is ignored.", t.getMessage(), t);
            }
            return true;
        }
}