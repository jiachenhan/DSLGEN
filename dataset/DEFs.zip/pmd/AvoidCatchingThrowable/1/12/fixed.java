public class foo {
        private void executeReactiveWork() {
            for (;;) {
                final Runnable polled = queue.pollFirst();
                if (polled == null) {
                    if (back != null && !back.isEmpty()) {
                        queue = back.pollFirst();
                        continue;
                    } else {
                        break;
                    }
                }
                try {
                    if (stats) {
                        executor.pendingTasks.decrement();
                    }
                    if (LOG.isTraceEnabled()) {
                        LOG.trace("Worker #{} running: {}", number, polled);
                    }
                    polled.run();
                } catch (Exception t) {
                    LOG.warn("Error executing reactive work due to {}. This exception is ignored.",
                            t.getMessage(), t);
                }
            }
        }
}