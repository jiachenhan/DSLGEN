public class foo {
    public void remove(Video video) {
        if (mVideos == null) {
            return;
        }

        try {
            // ConcurrentModificationException fix
            Helpers.removeIf(mVideos, item -> Helpers.equals(item, video));
            //mVideos.remove(video);
        } catch (UnsupportedOperationException e) { // read only collection
            e.printStackTrace();
        }
    }
}