public class foo {
		@Override
		public void run() {
			String line = null;
			try {
				while ((line = shellOutput.readLine()) != null) {
					buffer.append(line).append('\n');
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				buffer = null;
			}
		}
}