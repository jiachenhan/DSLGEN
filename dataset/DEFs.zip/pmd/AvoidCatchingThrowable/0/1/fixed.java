public class foo {
    /**
     * 1. If target file does not exist, then move .merge file to target file <br>
     * 2. If target resource file does not exist, then serialize it. <br>
     * 3. Append merging modification to target mods file and delete merging mods file. <br>
     * 4. Delete source files and .merge file. <br>
     */
    @SuppressWarnings("squid:S3776")
    private boolean handleCrossCompactionWithSomeSourceFilesLostBefore013(
        List<TsFileIdentifier> targetFileIdentifiers,
        List<TsFileIdentifier> sourceFileIdentifiers) {
      try {
        File compactionModsFileFromOld =
            new File(
                tsFileManager.getStorageGroupDir()
                    + File.separator
                    + IoTDBConstant.COMPACTION_MODIFICATION_FILE_NAME_FROM_OLD);
        List<TsFileResource> targetFileResources = new ArrayList<>();
        for (int i = 0; i < sourceFileIdentifiers.size(); i++) {
          TsFileIdentifier sourceFileIdentifier = sourceFileIdentifiers.get(i);
          if (sourceFileIdentifier.isSequence()) {
            File tmpTargetFile = targetFileIdentifiers.get(i).getFileFromDataDirs();
            File targetFile = null;

            // move tmp target file to target file if not exist
            if (tmpTargetFile != null) {
              // move tmp target file to target file
              String sourceFilePath =
                  tmpTargetFile
                      .getPath()
                      .replace(
                          TsFileConstant.TSFILE_SUFFIX
                              + IoTDBConstant.CROSS_COMPACTION_TMP_FILE_SUFFIX_FROM_OLD,
                          TsFileConstant.TSFILE_SUFFIX);
              targetFile = TsFileNameGenerator.increaseCrossCompactionCnt(new File(sourceFilePath));
              FSFactoryProducer.getFSFactory().moveFile(tmpTargetFile, targetFile);
            } else {
              // target file must exist
              File file =
                  TsFileNameGenerator.increaseCrossCompactionCnt(
                      new File(
                          targetFileIdentifiers
                              .get(i)
                              .getFilePath()
                              .replace(
                                  TsFileConstant.TSFILE_SUFFIX
                                      + IoTDBConstant.CROSS_COMPACTION_TMP_FILE_SUFFIX_FROM_OLD,
                                  TsFileConstant.TSFILE_SUFFIX)));

              targetFile = getFileFromDataDirs(file.getPath());
            }
            if (targetFile == null) {
              logger.error(
                  "{} [Compaction][Recover] target file of source seq file {} "
                      + "does not exist (<0.13).",
                  fullStorageGroupName,
                  sourceFileIdentifier.getFilePath());
              return false;
            }

            // serialize target resource file if not exist
            TsFileResource targetResource = new TsFileResource(targetFile);
            if (!targetResource.resourceFileExists()) {
              try (TsFileSequenceReader reader =
                  new TsFileSequenceReader(targetFile.getAbsolutePath())) {
                FileLoaderUtils.updateTsFileResource(reader, targetResource);
              }
              targetResource.serialize();
            }

            targetFileResources.add(targetResource);

            // append compaction modifications to target mods file and delete compaction mods file
            if (compactionModsFileFromOld.exists()) {
              ModificationFile compactionModsFile =
                  new ModificationFile(compactionModsFileFromOld.getPath());
              appendCompactionModificationsBefore013(targetResource, compactionModsFile);
            }

            // delete tmp target file
            if (!checkAndDeleteFile(tmpTargetFile)) {
              return false;
            }
          }

          // delete source tsfile
          File sourceFile = sourceFileIdentifier.getFileFromDataDirs();
          if (!checkAndDeleteFile(sourceFile)) {
            return false;
          }

          // delete source resource file
          sourceFile =
              getFileFromDataDirs(
                  sourceFileIdentifier.getFilePath() + TsFileResource.RESOURCE_SUFFIX);
          if (!checkAndDeleteFile(sourceFile)) {
            return false;
          }

          // delete source mods file
          sourceFile =
              getFileFromDataDirs(
                  sourceFileIdentifier.getFilePath() + ModificationFile.FILE_SUFFIX);
          if (!checkAndDeleteFile(sourceFile)) {
            return false;
          }
        }

        // delete compaction mods file
        if (!checkAndDeleteFile(compactionModsFileFromOld)) {
          return false;
        }
      } catch (IOException e) {
        logger.error(
            "{} [Compaction][Recover] fail to handle with some source files lost from old version.",
            fullStorageGroupName,
            e);
        return false;
      }

      return true;
    }
}