public class foo {
    @Test
    public void doStopOpenRequest() throws Exception {
        sut.openRequests.incrementAndGet();
        sut.doStop();
    }
}