public class foo {
  public void testWriteBytes() throws IOException {
    File temp = createTempFile();
    byte[] data = newPreFilledByteArray(2000);
    Files.write(data, temp);
    assertTrue(Arrays.equals(data, Files.toByteArray(temp)));

    assertThrows(NullPointerException.class, () -> Files.write(null, temp));
  }
}