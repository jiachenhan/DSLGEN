public class foo {
  @Override
  protected void setupHttpClientsAndUsers() throws Exception
  {
    super.setupHttpClientsAndUsers();

    // Add a delay to allow propagation of credentials to all services
    try {
      Thread.sleep(5000);
    }
    catch (Throwable t) {
      // Ignore exception
    }
  }
}