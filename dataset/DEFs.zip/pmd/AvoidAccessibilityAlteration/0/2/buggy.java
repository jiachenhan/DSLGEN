public class foo {
    @Fold
    static EnumSet<?> getStaticFeatures() {
        Architecture arch = ConfigurationValues.getTarget().arch;
        if (arch instanceof AMD64) {
            return ((AMD64) arch).getFeatures();
        } else if (arch instanceof AArch64) {
            return ((AArch64) arch).getFeatures();
        } else if (ShadowedRISCV64.instanceOf(arch)) {
            Method getFeatures = RISCV64ReflectionUtil.lookupMethod(ShadowedRISCV64.riscv64OrNull, "getFeatures");
            getFeatures.setAccessible(true);
            return (EnumSet<?>) RISCV64ReflectionUtil.invokeMethod(getFeatures, arch);
        } else {
            throw GraalError.shouldNotReachHere("unsupported architecture"); // ExcludeFromJacocoGeneratedReport
        }
    }
}