public class foo {
    @Override
    public void validatePerSSTableIndexComponents(IndexDescriptor indexDescriptor, boolean checksum)
    {
        for (IndexComponent indexComponent : perSSTableIndexComponents())
        {
            if (isNotBuildCompletionMarker(indexComponent))
            {
                try (IndexInput input = indexDescriptor.openPerSSTableInput(indexComponent))
                {
                    if (checksum)
                        SAICodecUtils.validateChecksum(input);
                    else
                        SAICodecUtils.validate(input);
                }
                catch (Exception e)
                {
                    logger.warn(indexDescriptor.logMessage("{} failed for index component {} on SSTable {}."),
                                                           checksum ? "Checksum validation" : "Validation",
                                                           indexComponent,
                                                           indexDescriptor.sstableDescriptor);
                    rethrowIOException(e);
                }
            }
        }
    }
}