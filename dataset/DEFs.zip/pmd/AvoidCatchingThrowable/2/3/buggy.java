public class foo {
    protected boolean doProcess(Exchange exchange, AsyncCallback callback) {
        Iterable<ProcessorExchangePair> pairs;
        int size = 0;
        try {
            pairs = createProcessorExchangePairs(exchange);
            if (pairs instanceof Collection) {
                size = ((Collection<ProcessorExchangePair>) pairs).size();
            }
        } catch (Throwable e) {
            exchange.setException(e);
            // unexpected exception was thrown, maybe from iterator etc. so do not regard as exhausted
            // and do the done work
            doDone(exchange, null, null, callback, true, false);
            return true;
        }

        // we need to run in either transacted or reactive mode because the threading model is different
        // when we run in transacted mode, then we synchronous processing on the current thread
        // this can lead to a long execution which can lead to deep stackframes, and therefore we
        // must handle this specially in a while loop structure to ensure the strackframe does not grow deeper
        // the reactive mode will execute each sub task in its own runnable task which is scheduled on the reactive executor
        // which is how the routing engine normally operates
        // if we have parallel processing enabled then we cannot run in transacted mode (requires synchronous processing via same thread)
        MulticastTask state = !isParallelProcessing() && exchange.isTransacted()
                ? new MulticastTransactedTask(exchange, pairs, callback, size)
                : new MulticastReactiveTask(exchange, pairs, callback, size);
        if (isParallelProcessing()) {
            executorService.submit(() -> reactiveExecutor.schedule(state));
        } else {
            if (exchange.isTransacted()) {
                reactiveExecutor.scheduleQueue(state);
            } else {
                reactiveExecutor.scheduleMain(state);
            }
        }

        // the remainder of the multicast will be completed async
        // so we break out now, then the callback will be invoked which then
        // continue routing from where we left here
        return false;
    }
}