public class foo {
    private void updateTaskStatus(TaskStatus status)
    {
        boolean isDone = status.getState().isDone();
        if (!isDone && stateMachine.getState() == StageState.RUNNING) {
            return;
        }
        synchronized (this) {
            if (isDone) {
                finishedTasks.add(status.getTaskId());
            }
            if (finishedTasks.size() == allTasks.size()) {
                stateMachine.transitionToPending();
            }
            else {
                stateMachine.transitionToRunning();
            }
        }
    }
}