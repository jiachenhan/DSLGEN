public class foo {
  @Test
  public void testGetAdapter_Null() {
    Gson gson = new Gson();
    NullPointerException e = assertThrows(NullPointerException.class, () -> gson.getAdapter((TypeToken<?>) null));
    assertThat(e).hasMessageThat().isEqualTo("type must not be null");
  }
}