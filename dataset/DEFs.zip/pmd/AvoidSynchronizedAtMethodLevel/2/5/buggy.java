public class foo {
    private synchronized <T extends Writable> void logEdit(short op, List<T> entries) throws IOException {
        JournalBatch batch = new JournalBatch(35);
        for (T entry : entries) {
            // the number of batch entities to less than 32 and the batch data size to less than 640KB
            if (batch.getJournalEntities().size() >= 32 || batch.getSize() >= 640 * 1024) {
                journal.write(batch);
                batch = new JournalBatch(35);
            }
            batch.addJournal(op, entry);
        }
        if (!batch.getJournalEntities().isEmpty()) {
            journal.write(batch);
        }
    }
}