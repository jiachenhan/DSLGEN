public class foo {
  @Test
  public void testDBErrNewLookup() throws Exception
  {
    final HttpServletRequest request = createMockRequest(true);

    final Capture<AuditInfo> auditInfoCapture = Capture.newInstance();
    final LookupCoordinatorManager lookupCoordinatorManager = EasyMock.createStrictMock(
        LookupCoordinatorManager.class);
    EasyMock.expect(lookupCoordinatorManager.updateLookup(
        EasyMock.eq(LOOKUP_TIER),
        EasyMock.eq(LOOKUP_NAME),
        EasyMock.eq(SINGLE_LOOKUP),
        EasyMock.capture(auditInfoCapture)
    )).andReturn(false).once();

    EasyMock.replay(lookupCoordinatorManager, request);

    final LookupCoordinatorResource lookupCoordinatorResource = new LookupCoordinatorResource(
        lookupCoordinatorManager,
        MAPPER,
        MAPPER
    );
    final Response response = lookupCoordinatorResource.createOrUpdateLookup(
        LOOKUP_TIER,
        LOOKUP_NAME,
        EMPTY_MAP_SOURCE.openStream(),
        request
    );

    Assert.assertEquals(500, response.getStatus());
    Assert.assertEquals(ImmutableMap.of("error", "Unknown error updating configuration"), response.getEntity());
    Assert.assertTrue(auditInfoCapture.hasCaptured());
    Assert.assertEquals(auditInfo, auditInfoCapture.getValue());

    EasyMock.verify(lookupCoordinatorManager, request);
  }
}