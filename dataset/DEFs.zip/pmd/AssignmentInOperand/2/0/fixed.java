public class foo {
	private void processLabel(DIEAggregate diea) {
		if (!shouldProcess(diea)) {
			return;
		}

		String name = prog.getEntryName(diea);
		DWARFRange labelPc = diea.getPCRange();
		if (name != null && !labelPc.isEmpty() && labelPc.getFrom() != 0) {
			Address address = prog.getCodeAddress(labelPc.getFrom());
			try {
				SymbolTable symbolTable = currentProgram.getSymbolTable();
				symbolTable.createLabel(address, name, currentProgram.getGlobalNamespace(),
					SourceType.IMPORTED);

				String locationInfo = DWARFSourceInfo.getDescriptionStr(diea);
				if (locationInfo != null) {
					appendComment(address, CodeUnit.EOL_COMMENT, locationInfo, "; ");
				}
			}
			catch (InvalidInputException e) {
				Msg.error(this, "Problem creating label at " + address + " with name " + name, e);
			}
		}
	}
}