public class foo {
  public void testNullMonitorInGuardConstructorThrowsNPE() {
    try {
      new FlagGuard(null);
      fail("expected NullPointerException");
    } catch (NullPointerException expected) {
    }
  }
}