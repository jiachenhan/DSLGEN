public class foo {
  public void testFromByteArray_withNullInputThrowsNullPointerException() {
    try {
      PairedStats.fromByteArray(null);
      fail("Expected NullPointerException");
    } catch (NullPointerException expected) {
    }
  }
}