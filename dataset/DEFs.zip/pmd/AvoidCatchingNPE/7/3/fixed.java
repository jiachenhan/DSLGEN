public class foo {
  public void testCopyOf_multisetContainingNull() {
    Multiset<String> c = HashMultiset.create(asList("a", null, "b"));
    assertThrows(NullPointerException.class, () -> ImmutableSortedMultiset.copyOf(c));
  }
}