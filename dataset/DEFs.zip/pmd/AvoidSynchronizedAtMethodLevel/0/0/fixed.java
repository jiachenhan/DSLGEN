public class foo {
        void kill() {
            StopAction action;
            synchronized (this) {
                action = updateKillState(KILL);
            }
            if (action != null) {
                getContext().getEnv().submitThreadLocal(new Thread[]{action.host}, action);
            }
        }
}