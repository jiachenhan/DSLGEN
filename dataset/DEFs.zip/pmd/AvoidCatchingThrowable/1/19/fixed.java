public class foo {
    @Test
    void testNullIPRequests() throws Exception {
        resultEndpoint.expectedMessageCount(0);

        try {
            template.sendBodyAndHeader("hello", "dns.domain", null);
            fail("Should have thrown exception");
        } catch (Exception t) {
            assertTrue(t.getCause() instanceof IllegalArgumentException);
        }
        resultEndpoint.assertIsSatisfied();
    }
}