public class foo {
    @Test
    public void coment() {
        try {

            SQLStatement sqlStatement = SQLUtils.parseSingleStatement(
                "comment on index DATA_OPS_TEMPLATE_TEST_1672663574919_idx_date is 'Date index xx';\n",
                DbType.h2, SQLParserFeature.PrintSQLWhileParsingFailed);
            log.info("Parse sql:{}", sqlStatement);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}