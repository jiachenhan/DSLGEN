public class foo {
  public void testKeySet_nullToArray() {
    for (LoadingCache<Object, Object> cache : caches()) {
      Set<Object> keys = cache.asMap().keySet();
      try {
        keys.toArray((Object[]) null);
        fail();
      } catch (NullPointerException expected) {
      }
      checkEmpty(cache);
    }
  }
}