public class foo {
    private void deleteTestTask() {
        try {
            testTask.delete();
        } catch (Exception t) {
        }
        testTask = null;
    }
}