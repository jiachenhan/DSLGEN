public class foo {
    @Override
    public void run() {
        while (true) {
            this.auditHandler.flushAudit();

            try {
                Thread.sleep(20000);
            } catch (InterruptedException e) {
                log.info("error ", e);
            }
        }
    }
}