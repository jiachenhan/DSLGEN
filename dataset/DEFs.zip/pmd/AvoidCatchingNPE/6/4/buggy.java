public class foo {
  public void testTransform_present_functionReturnsNull() {
    try {
      Optional<String> unused =
          Optional.of("a")
              .transform(
                  (Function<String, String>)
                      new Function<String, @Nullable String>() {
                        @Override
                        public @Nullable String apply(String input) {
                          return null;
                        }
                      });
      fail("Should throw if Function returns null.");
    } catch (NullPointerException expected) {
    }
  }
}