public class foo {
    public void clear() {
        lock.lock();
        value = null;
        lock.unlock();
    }
}