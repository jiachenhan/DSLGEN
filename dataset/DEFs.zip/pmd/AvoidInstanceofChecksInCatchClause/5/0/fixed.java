public class foo {
	@Test
	@Disabled
	public void downloadFileFromUrlTest4() {
		File file = null;
		try {
			file = HttpDownloader.downloadFile("http://groovy-lang.org/changelogs/changelog-3.0.5.html", FileUtil.file("d:/download/temp"), 1);

			Assertions.assertNotNull(file);
			Assertions.assertTrue(file.exists());
			Assertions.assertTrue(file.isFile());
			Assertions.assertTrue(file.length() > 0);
			Assertions.assertFalse(file.getName().isEmpty());
		} catch (final Exception e) {
			Assertions.assertInstanceOf(IORuntimeException.class, e);
		} finally {
			FileUtil.del(file);
		}
	}
}