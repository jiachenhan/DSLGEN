public class foo {
  public void testEntrySet_nullToArray() {
    for (LoadingCache<Object, Object> cache : caches()) {
      Set<Entry<Object, Object>> entries = cache.asMap().entrySet();
      try {
        entries.toArray((Entry<Object, Object>[]) null);
        fail();
      } catch (NullPointerException expected) {
      }
      checkEmpty(cache);
    }
  }
}