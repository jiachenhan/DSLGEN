public class foo {
        private S loadExtension(ClassLoader loader, Class<?>[] argTypes,
                                Object[] args) {
            try {
                loadAllExtensionClass(loader);
                ExtensionDefinition<S> defaultExtensionDefinition = getDefaultExtensionDefinition();
                return getExtensionInstance(defaultExtensionDefinition, loader, argTypes, args);
            } catch (Throwable e) {
                if (e instanceof EnhancedServiceNotFoundException) {
                    throw (EnhancedServiceNotFoundException)e;
                } else {
                    throw new EnhancedServiceNotFoundException(
                        "not found service provider for : " + type.getName() + " caused by " + ExceptionUtils
                            .getFullStackTrace(e));
                }
            }
        }
}