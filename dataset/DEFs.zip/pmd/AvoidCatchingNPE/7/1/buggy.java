public class foo {
  public void testCreation_arrayContainingOnlyNull() {
    String[] array = new String[] {null};
    try {
      ImmutableSortedMultiset.copyOf(array);
      fail();
    } catch (NullPointerException expected) {
    }
  }
}