public class foo {
  public void testFirstNonNull_throwsNullPointerException() {
    try {
      MoreObjects.firstNonNull(null, null);
      fail();
    } catch (NullPointerException expected) {
    }
  }
}