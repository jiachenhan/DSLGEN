public class foo {
    protected void deleteTestFile() {
        try {
            testFile.delete();
        } catch (Exception t) {
        }
        testFile = null;
    }
}