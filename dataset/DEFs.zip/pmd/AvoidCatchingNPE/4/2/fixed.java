public class foo {
  public void testKeySet_nullToArray() {
    for (LoadingCache<Object, Object> cache : caches()) {
      Set<Object> keys = cache.asMap().keySet();
      assertThrows(NullPointerException.class, () -> keys.toArray((Object[]) null));
      checkEmpty(cache);
    }
  }
}