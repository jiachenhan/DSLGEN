public class foo {
  public void testCopyOf_iteratorContainingNull() {
    Iterator<String> iterator = asList("a", null, "b").iterator();
    assertThrows(NullPointerException.class, () -> ImmutableSortedMultiset.copyOf(iterator));
  }
}