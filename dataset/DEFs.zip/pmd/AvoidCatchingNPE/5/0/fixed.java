public class foo {
  public void testThrowIfUnchecked_null() {
    assertThrows(NullPointerException.class, () -> throwIfUnchecked(null));
  }
}