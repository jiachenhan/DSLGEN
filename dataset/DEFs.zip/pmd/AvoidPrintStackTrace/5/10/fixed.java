public class foo {
    /**
     * 关闭数据库连接池
     *
     * @param dbKey
     * @return
     */
    public static void closeDbKey(final String dbKey) {
        DruidDataSource dataSource = getDbSourceByDbKey(dbKey);
        try {
            if (dataSource != null && !dataSource.isClosed()) {
                dataSource.getConnection().commit();
                dataSource.getConnection().close();
                dataSource.close();
                DataSourceCachePool.removeCache(dbKey);
            }
        } catch (SQLException e) {
            log.info(e.getMessage(), e);
        }
    }
}