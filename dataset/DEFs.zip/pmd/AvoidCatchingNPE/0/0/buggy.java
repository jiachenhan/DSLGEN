public class foo {
    @Test
    public void injectClass_bootstrapClass() {
        PluginConfig pluginConfig = newPluginConfig();

        ClassInjector plainClassLoaderHandler = new PlainClassLoaderHandler(pluginConfig);
        try {
            plainClassLoaderHandler.injectClass(this.getClass().getClassLoader(), "com.navercorp.pinpoint.bootstrap.Test");
            Assertions.fail();
        } catch (NullPointerException e) {
            Assertions.fail();
        } catch (Exception e) {

        }
    }
}