public class foo {
  public void testNewReferenceArray_withNullArray() throws Exception {
    assertThrows(NullPointerException.class, () -> Atomics.newReferenceArray(null));
  }
}