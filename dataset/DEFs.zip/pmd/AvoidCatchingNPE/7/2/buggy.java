public class foo {
  public void testCopyOf_collectionContainingNull() {
    Collection<String> c = MinimalCollection.of("a", null, "b");
    try {
      ImmutableSortedMultiset.copyOf(c);
      fail();
    } catch (NullPointerException expected) {
    }
  }
}