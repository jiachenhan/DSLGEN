public class foo {
        void stop(StaticObject death) {
            StopAction action = null;
            synchronized (this) {
                KillStatus s = status;
                if (s.canStop()) {
                    // Writing the throwable must be done before the kill status can be observed
                    throwable = death;
                    action = updateKillState(STOP);
                }
            }
            if (action != null) {
                getContext().getEnv().submitThreadLocal(new Thread[]{action.host}, action);
            }
        }
}