public class foo {
    @Override
    public boolean process(Exchange exchange, AsyncCallback callback) {
        if (!isStarted()) {
            exchange.setException(new IllegalStateException("Producer has not been started: " + this));
            callback.done(true);
            return true;
        }

        final boolean sending = EventHelper.notifyExchangeSending(exchange.getContext(), exchange, getEndpoint());
        // record timing for sending the exchange using the producer
        StopWatch watch;
        if (sending) {
            watch = new StopWatch();
        } else {
            watch = null;
        }

        try {
            LOG.debug(">>>> {} {}", getEndpoint(), exchange);
            return producer.process(exchange, new AsyncCallback() {
                @Override
                public void done(boolean doneSync) {
                    try {
                        // emit event that the exchange was sent to the endpoint
                        if (watch != null) {
                            long timeTaken = watch.taken();
                            EventHelper.notifyExchangeSent(exchange.getContext(), exchange, getEndpoint(), timeTaken);
                        }
                    } finally {
                        callback.done(doneSync);
                    }
                }
            });
        } catch (Exception throwable) {
            exchange.setException(throwable);
            callback.done(true);
        }

        return true;
    }
}