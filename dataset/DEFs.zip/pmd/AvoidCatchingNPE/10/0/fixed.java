public class foo {
  public void testNull() {
    assertThrows(
        NullPointerException.class, () -> map.putInstance((TypeToken) null, new Integer(1)));
    map.putInstance(Integer.class, null);
    assertTrue(map.containsKey(TypeToken.of(Integer.class)));
    assertTrue(map.entrySet().contains(immutableEntry(TypeToken.of(Integer.class), null)));
    assertNull(map.get(TypeToken.of(Integer.class)));
    assertNull(map.getInstance(Integer.class));

    map.putInstance(Long.class, null);
    assertTrue(map.containsKey(TypeToken.of(Long.class)));
    assertTrue(map.entrySet().contains(immutableEntry(TypeToken.of(Long.class), null)));
    assertNull(map.get(TypeToken.of(Long.class)));
    assertNull(map.getInstance(Long.class));
  }
}