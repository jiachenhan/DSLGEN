public class foo {
  @Test
  public void testGetInsertNodeInParallel() throws IllegalPathException {
    // write memTable
    IMemTable memTable = new PrimitiveMemTable(databasePath, dataRegionId);
    walNode.onMemTableCreated(memTable, logDirectory + "/" + "fake.tsfile");
    InsertRowNode node1 = getInsertRowNode(System.currentTimeMillis());
    node1.setSearchIndex(1);
    WALFlushListener flushListener = walNode.log(memTable.getMemTableId(), node1);
    WALEntryPosition position = flushListener.getWalEntryHandler().getWalEntryPosition();
    // wait until wal flushed
    walNode.rollWALFile();
    Awaitility.await().until(() -> walNode.isAllWALEntriesConsumed() && position.canRead());
    // Test getInsertNode in parallel to detect buffer concurrent problem
    AtomicBoolean failure = new AtomicBoolean(false);
    List<Thread> threadList = new ArrayList<>(5);
    for (int i = 0; i < 5; ++i) {
      Thread getInsertNodeThread =
          new Thread(
              () -> {
                if (!node1.equals(cache.getInsertNode(position))) {
                  failure.set(true);
                }
              });
      threadList.add(getInsertNodeThread);
      getInsertNodeThread.start();
    }
    Awaitility.await()
        .until(
            () -> {
              for (Thread thread : threadList) {
                if (thread.isAlive()) {
                  return false;
                }
              }
              return true;
            });
    assertFalse(failure.get());
  }
}