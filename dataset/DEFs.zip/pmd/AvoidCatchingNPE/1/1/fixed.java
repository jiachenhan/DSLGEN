public class foo {
  public void testWeak_null() {
    Interner<String> pool = Interners.newWeakInterner();
    assertThrows(NullPointerException.class, () -> pool.intern(null));
  }
}