public class foo {
  public void testGetUnchecked_null() {
    for (LoadingCache<Object, Object> cache : caches()) {
      try {
        cache.getUnchecked(null);
        fail("Expected NullPointerException");
      } catch (NullPointerException expected) {
      }
      checkEmpty(cache);
    }
  }
}