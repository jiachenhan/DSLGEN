public class foo {
  /**
   * Using try lock method to prevent deadlock when stopping all pipes with critical exceptions and
   * {@link PipeTaskDataNodeAgent#handlePipeMetaChanges(List)}} concurrently.
   */
  public void stopAllPipesWithCriticalException() {
    try {
      int retryCount = 0;
      while (true) {
        if (tryWriteLockWithTimeOut(5)) {
          try {
            stopAllPipesWithCriticalExceptionInternal();
            LOGGER.info("Stopped all pipes with critical exception.");
            return;
          } finally {
            releaseWriteLock();
          }
        } else {
          Thread.sleep(1000);
          LOGGER.warn(
              "Failed to stop all pipes with critical exception, retry count: {}.", ++retryCount);
        }
      }
    } catch (InterruptedException e) {
      LOGGER.error(
          "Interrupted when trying to stop all pipes with critical exception, exception message: {}",
          e.getMessage(),
          e);
      Thread.currentThread().interrupt();
    } catch (Exception e) {
      LOGGER.error(
          "Failed to stop all pipes with critical exception, exception message: {}",
          e.getMessage(),
          e);
    }
  }
}