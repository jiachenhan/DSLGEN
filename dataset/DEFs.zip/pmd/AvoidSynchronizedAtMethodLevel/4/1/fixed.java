public class foo {
    public void startProducer() {
        // Guarantee only one task call "producerBuilder.createAsync()".
        Pair<Boolean, State> setStartingRes = compareSetAndGetState(State.Disconnected, State.Starting);
        if (!setStartingRes.getLeft()) {
            if (setStartingRes.getRight() == State.Starting) {
                log.info("[{}] Skip the producer creation since other thread is doing starting, state : {}",
                        replicatorId, state);
            } else if (setStartingRes.getRight() == State.Started) {
                // Since the method "startProducer" will be called even if it is started, only print debug-level log.
                if (log.isDebugEnabled()) {
                    log.debug("[{}] Replicator was already running. state: {}", replicatorId, state);
                }
            } else if (setStartingRes.getRight() == State.Disconnecting) {
                if (log.isDebugEnabled()) {
                    log.debug("[{}] Rep.producer is closing, delay to retry(wait the producer close success)."
                            + " state: {}", replicatorId, state);
                }
                delayStartProducerAfterDisconnected();
            } else {
                /** {@link State.Terminating}, {@link State.Terminated}. **/
                log.info("[{}] Skip the producer creation since the replicator state is : {}", replicatorId, state);
            }
            return;
        }

        log.info("[{}] Starting replicator", replicatorId);
        producerBuilder.createAsync().thenAccept(producer -> {
            setProducerAndTriggerReadEntries(producer);
        }).exceptionally(ex -> {
            Pair<Boolean, State> setDisconnectedRes = compareSetAndGetState(State.Starting, State.Disconnected);
            if (setDisconnectedRes.getLeft()) {
                long waitTimeMs = backOff.next();
                log.warn("[{}] Failed to create remote producer ({}), retrying in {} s",
                        replicatorId, ex.getMessage(), waitTimeMs / 1000.0);
                // BackOff before retrying
                scheduleCheckTopicActiveAndStartProducer(waitTimeMs);
            } else {
                if (setDisconnectedRes.getRight() == State.Terminating
                        || setDisconnectedRes.getRight() == State.Terminated) {
                    log.info("[{}] Skip to create producer, because it has been terminated, state is : {}",
                            replicatorId, state);
                } else {
                    /** {@link  State.Disconnected}, {@link  State.Starting}, {@link  State.Started} **/
                    // Since only one task can call "producerBuilder.createAsync()", this scenario is not expected.
                    // So print a warn log.
                    log.warn("[{}] Other thread will try to create the producer again. so skipped current one task."
                                    + " State is : {}",
                            replicatorId, state);
                }
            }
            return null;
        });
    }
}