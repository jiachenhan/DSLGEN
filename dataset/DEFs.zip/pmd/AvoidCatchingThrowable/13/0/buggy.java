public class foo {
    @Override
    public TCreatePartitionResult createPartition(TCreatePartitionRequest request) throws TException {

        LOG.info("Receive create partition: {}", request);

        TCreatePartitionResult result;
        try {
            if (partitionRequestNum.incrementAndGet() >= Config.thrift_server_max_worker_threads / 4) {
                result = new TCreatePartitionResult();
                TStatus errorStatus = new TStatus(SERVICE_UNAVAILABLE);
                errorStatus.setError_msgs(Lists.newArrayList(
                        String.format("Too many create partition requests, please try again later txn_id=%d",
                        request.getTxn_id())));
                result.setStatus(errorStatus);
                return result;
            }

            result = createPartitionProcess(request);
        } catch (Throwable t) {
            LOG.warn(t);
            result = new TCreatePartitionResult();
            TStatus errorStatus = new TStatus(RUNTIME_ERROR);
            errorStatus.setError_msgs(Lists.newArrayList(String.format("txn_id=%d failed. %s",
                    request.getTxn_id(), t.getMessage())));
            result.setStatus(errorStatus);
        } finally {
            partitionRequestNum.decrementAndGet();
        }

        return result;
    }
}