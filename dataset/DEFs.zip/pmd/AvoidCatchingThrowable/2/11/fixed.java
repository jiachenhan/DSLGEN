public class foo {
    @Override
    public AsyncProducer acquireProducer(Endpoint endpoint) {
        // Try to favor thread locality as some data in the producer's cache may be shared among threads,
        // triggering cases of false sharing
        if (endpoint == lastUsedEndpoint && endpoint.isSingletonProducer()) {
            return lastUsedProducer;
        }

        try {
            AsyncProducer producer = producers.acquire(endpoint);
            if (statistics != null) {
                statistics.onHit(endpoint.getEndpointUri());
            }

            synchronized (this) {
                lastUsedEndpoint = endpoint;
                lastUsedProducer = producer;
            }

            return producer;
        } catch (Exception e) {
            throw new FailedToCreateProducerException(endpoint, e);
        }
    }
}