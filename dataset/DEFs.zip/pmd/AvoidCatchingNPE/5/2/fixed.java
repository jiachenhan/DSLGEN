public class foo {
  public void testGet_null() throws ExecutionException {
    for (LoadingCache<Object, Object> cache : caches()) {
      assertThrows(NullPointerException.class, () -> cache.get(null));
      checkEmpty(cache);
    }
  }
}