public class foo {
  @Override
  public ResultSetMetaData getMetaData() {
    String operationType = "";
    boolean nonAlign = false;
    try {
      if (statement.getResultSet() instanceof IoTDBJDBCResultSet) {
        operationType = ((IoTDBJDBCResultSet) statement.getResultSet()).getOperationType();
        this.sgColumns = ((IoTDBJDBCResultSet) statement.getResultSet()).getSgColumns();
      } else if (statement.getResultSet() instanceof IoTDBNonAlignJDBCResultSet) {
        operationType = ((IoTDBNonAlignJDBCResultSet) statement.getResultSet()).getOperationType();
        this.sgColumns = ((IoTDBNonAlignJDBCResultSet) statement.getResultSet()).getSgColumns();
        nonAlign = true;
      }
    } catch (SQLException throwables) {
      LOGGER.error(String.format("get meta data error:%s", throwables.getMessage()));
    }
    return new IoTDBResultMetadata(
        nonAlign,
        sgColumns,
        operationType,
        ioTDBRpcDataSet.columnNameList,
        ioTDBRpcDataSet.columnTypeList,
        ioTDBRpcDataSet.ignoreTimeStamp);
  }
}