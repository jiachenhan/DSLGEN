public class foo {
        @Override
        public void run() {
            final Rnd rnd = new Rnd();
            try {
                new SendAndReceiveRequestBuilder().executeMany(requester -> {
                    TestUtils.await(barrier);
                    for (int i = 0; i < count; i++) {
                        int index = rnd.nextPositiveInt() % requests.length;
                        try {
                            requester.execute(requests[index][0], requests[index][1]);
                        } catch (Throwable e) {
                            e.printStackTrace();
                            System.out.println("erm: " + index + ", ts=" + Timestamps.toString(Os.currentTimeMicros()));
                            throw e;
                        }
                    }
                });
            } catch (Throwable e) {
                e.printStackTrace();
                errorCounter.incrementAndGet();
            } finally {
                latch.countDown();
            }
        }
}