public class foo {
  @Override
  public ResultSet getVersionColumns(String catalog, String schema, String table)
      throws SQLException {
    List<String> columnNameList = new ArrayList<String>();
    List<String> columnTypeList = new ArrayList<String>();
    Map<String, Integer> columnNameIndex = new HashMap<String, Integer>();
    Statement stmt = connection.createStatement();
    try {
      Field[] fields = new Field[8];
      fields[0] = new Field("", "SCOPE", "INT32");
      fields[1] = new Field("", "COLUMN_NAME", "TEXT");
      fields[2] = new Field("", "DATA_TYPE", "INT32");
      fields[3] = new Field("", "TYPE_NAME", "TEXT");
      fields[4] = new Field("", "COLUMN_SIZE", "INT32");
      fields[5] = new Field("", "BUFFER_LENGTH", "INT32");
      fields[6] = new Field("", "DECIMAL_DIGITS", "INT32");
      fields[7] = new Field("", "PSEUDO_COLUMN", "INT32");
      for (int i = 0; i < fields.length; i++) {
        columnNameList.add(fields[i].getName());
        columnTypeList.add(fields[i].getSqlType());
        columnNameIndex.put(fields[i].getName(), i);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      close(null, stmt);
    }
    return new IoTDBJDBCResultSet(
        stmt,
        columnNameList,
        columnTypeList,
        columnNameIndex,
        false,
        client,
        null,
        -1,
        sessionId,
        null,
        null,
        (long) 60 * 1000,
        false);
  }
}