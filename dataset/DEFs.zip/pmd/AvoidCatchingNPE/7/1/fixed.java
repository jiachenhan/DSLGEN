public class foo {
  public void testCreation_arrayContainingOnlyNull() {
    String[] array = new String[] {null};
    assertThrows(NullPointerException.class, () -> ImmutableSortedMultiset.copyOf(array));
  }
}