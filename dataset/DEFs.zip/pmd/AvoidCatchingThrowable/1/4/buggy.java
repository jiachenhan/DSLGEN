public class foo {
    @Test
    void testDNSWithNoHeaders() throws Exception {
        resultEndpoint.expectedMessageCount(0);
        try {
            template.sendBody("hello");
            fail("Should have thrown exception");
        } catch (Throwable t) {
            assertTrue(t.getCause() instanceof IllegalArgumentException);
        }
        resultEndpoint.assertIsSatisfied();
    }
}