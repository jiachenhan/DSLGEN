public class foo {
	@Test
	@Disabled
	public void phaserTest(){
		final LocalDateTime now = TimeUtil.parse("2022-08-04T22:59:59+08:00", DateTimeFormatter.ISO_OFFSET_DATE_TIME);
		Assertions.assertNotNull(now);

		final int repeat = 30; // 执行的轮数配置
		final Phaser phaser = new Phaser() {  // 进行一些处理方法的覆写
			//返回ture: 移相器终止，false: 移相器继续执行
			@Override
			protected boolean onAdvance(final int phase, final int registeredParties) { // 回调处理
				System.out.printf("【onAdvance()处理】进阶处理操作，phase = %s、registeredParties = %s%n",
						phase, registeredParties);
				return phase + 1 >= repeat || registeredParties == 0; // 终止处理
			}
		};
		for (int x = 0; x < 2; x++) {   // 循环创建2个线程
			phaser.register(); // 注册参与者的线程
			new Thread(()->{ // 每一个线程都在持续的执行之中
				while (!phaser.isTerminated()) { // 现在没有终止Phaser执行
					try {
						TimeUnit.SECONDS.sleep(RandomUtil.randomInt(1, 10)); // 增加操作延迟,模拟各个线程执行时间不多。阿超、阿珍准备爱果的时间不同
					} catch (final InterruptedException e) {
						throw new HutoolException(e);
					}
					phaser.arriveAndAwaitAdvance(); // 等待其他的线程就位； 准备就绪，并等待其他线程就绪; 阿超、阿珍准备好了爱果，相互等待见面共度美好的一天
					final String date = TimeUtil.formatNormal(now.plusYears(phaser.getPhase() - 1)); // 增加一年
					System.out.printf("【%s】%s 阿超和阿珍共度了一个美好的七夕。%n", date, Thread.currentThread().getName());
					ThreadUtil.sleep(3, TimeUnit.SECONDS);
				}
			}, "子线程 - " + (x == 0 ? "阿超" : "阿珍")).start();
		}

		ThreadUtil.waitForDie();
	}
}