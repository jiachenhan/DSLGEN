public class foo {
	public synchronized void unloadAttributes() {
		if (attributes.isEmpty()) {
			return;
		}
		attributes.entrySet().removeIf(entry -> !entry.getValue().keepLoaded());
	}
}