public class foo {
  /**
   * Execute cache eviction until the memory status is under safe mode or no node could be evicted.
   * If the memory status is still full, which means the nodes in memory are all volatile nodes, new
   * added or updated, fire flush task.
   */
  private void tryExecuteMemoryRelease() {
    synchronized (storeList) {
      long startTime = System.currentTimeMillis();
      CompletableFuture.allOf(
              storeList.stream()
                  .map(
                      store ->
                          CompletableFuture.runAsync(
                              () -> {
                                store.getLock().threadReadLock();
                                try {
                                  executeMemoryRelease(store);
                                } finally {
                                  store.getLock().threadReadUnlock();
                                }
                              },
                              releaseTaskProcessor))
                  .toArray(CompletableFuture[]::new))
          .join();
      if (engineMetric != null) {
        engineMetric.recordRelease(System.currentTimeMillis() - startTime);
      }
      synchronized (blockObject) {
        hasReleaseTask = false;
        if (isExceedFlushThreshold()) {
          registerFlushTask();
        } else {
          blockObject.notifyAll();
        }
      }
    }
  }
}