public class foo {
    public static byte[] readResource(String resourcePath) {
        try (InputStream is = Grasscutter.class.getResourceAsStream(resourcePath)) {
            return is.readAllBytes();
        } catch (Exception exception) {
            Grasscutter.getLogger().warn("Failed to read resource: " + resourcePath);
            Grasscutter.getLogger().debug("Failed to load resource: " + resourcePath, exception);
        }

        return new byte[0];
    }
}