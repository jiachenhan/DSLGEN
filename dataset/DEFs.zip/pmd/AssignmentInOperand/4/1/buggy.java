public class foo {
    /**
     * Case-insensitive comparison of two char sequences, with subsequence over second.
     *
     * @param l   left sequence
     * @param r   right sequence
     * @param rLo right sequence lower bound
     * @param rHi right sequence upper bound
     * @return true if sequences match exactly (ignoring char case)
     */
    public static boolean equalsIgnoreCase(@NotNull CharSequence l, @NotNull CharSequence r, int rLo, int rHi) {
        if (l == r) {
            return true;
        }

        int ll;
        if ((ll = l.length()) != rHi - rLo) {
            return false;
        }

        return equalsCharsIgnoreCase(l, r, ll, rLo, rHi);
    }
}