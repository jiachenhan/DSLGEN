public class foo {
  public void testGetUnchecked_null() {
    for (LoadingCache<Object, Object> cache : caches()) {
      assertThrows(NullPointerException.class, () -> cache.getUnchecked(null));
      checkEmpty(cache);
    }
  }
}