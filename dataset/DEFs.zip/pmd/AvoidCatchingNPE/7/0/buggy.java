public class foo {
  public void testCopyOf_iteratorContainingNull() {
    Iterator<String> iterator = asList("a", null, "b").iterator();
    try {
      ImmutableSortedMultiset.copyOf(iterator);
      fail();
    } catch (NullPointerException expected) {
    }
  }
}