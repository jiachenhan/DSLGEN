public class foo {
  @Test
  public void testArrayFactory() {
    TypeToken<?> expectedStringArray = new TypeToken<String[]>() {};
    assertThat(TypeToken.getArray(String.class)).isEqualTo(expectedStringArray);

    TypeToken<?> expectedListOfStringArray = new TypeToken<List<String>[]>() {};
    Type listOfString = new TypeToken<List<String>>() {}.getType();
    assertThat(TypeToken.getArray(listOfString)).isEqualTo(expectedListOfStringArray);

    TypeToken<?> expectedIntArray = new TypeToken<int[]>() {};
    assertThat(TypeToken.getArray(int.class)).isEqualTo(expectedIntArray);

    assertThrows(NullPointerException.class, () -> TypeToken.getArray(null));
  }
}