public class foo {
  public void testSetFailureNull() throws Exception {
    assertThrows(NullPointerException.class, () -> future.setException(null));
    assertFalse(future.isDone());
    assertTrue(future.setException(new Exception("failure")));
    tester.testFailedFuture("failure");
  }
}