public class foo {
	/**
	 * Dispose associated buffer file and unexport this instance.
	 */
	@Override
	public void dispose() {

		removeOwnerInstance(this);
		removePathInstance(this);

		synchronized (this) {
			if (!disposed) {
				try {
					unexportObject(this, true);
				}
				catch (NoSuchObjectException e) {
					// ignore
				}
				bufferFile.dispose();
				disposed = true;
			}
		}
	}
}