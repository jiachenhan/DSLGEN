public class foo {
    public void invoke() {
        RpcContext.restoreCancellationContext(cancellationContext);
        InetSocketAddress remoteAddress = (InetSocketAddress) invocation.getAttributes()
            .remove(AbstractServerCall.REMOTE_ADDRESS_KEY);
        RpcContext.getServerContext().setRemoteAddress(remoteAddress);
        String remoteApp = (String) invocation.getAttributes()
            .remove(TripleHeaderEnum.CONSUMER_APP_NAME_KEY);
        if (null != remoteApp) {
            RpcContext.getServerContext().setRemoteApplicationName(remoteApp);
            invocation.setAttachmentIfAbsent(REMOTE_APPLICATION_KEY, remoteApp);
        }
        final long stInMillis = System.currentTimeMillis();
        try {
            final Result response = invoker.invoke(invocation);
            response.whenCompleteWithContext((r, t) -> {
                responseObserver.setResponseAttachments(response.getObjectAttachments());
                if (t != null) {
                    responseObserver.onError(t);
                    return;
                }
                if (response.hasException()) {
                    responseObserver.onError(response.getException());
                    return;
                }
                final long cost = System.currentTimeMillis() - stInMillis;
                if (responseObserver.isTimeout(cost)) {
                    LOGGER.error(PROTOCOL_TIMEOUT_SERVER, "", "", String.format(
                        "Invoke timeout at server side, ignored to send response. service=%s method=%s cost=%s",
                        invocation.getTargetServiceUniqueName(),
                        invocation.getMethodName(),
                        cost));
                    responseObserver.onCompleted(TriRpcStatus.DEADLINE_EXCEEDED);
                    return;
                }
                onReturn(r.getValue());
            });
        } catch (Exception e) {
            responseObserver.onError(e);
        } finally {
            RpcContext.removeCancellationContext();
            RpcContext.removeContext();
        }
    }
}