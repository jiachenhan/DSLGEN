public class foo {
  @Override
  public ResultSet getProcedureColumns(String arg0, String arg1, String arg2, String arg3)
      throws SQLException {
    List<String> columnNameList = new ArrayList<>();
    List<String> columnTypeList = new ArrayList<>();
    Map<String, Integer> columnNameIndex = new HashMap<>();
    Statement stmt = connection.createStatement();
    try {

      Field[] fields = new Field[20];
      fields[0] = new Field("", "PROCEDURE_CAT", "TEXT");
      fields[1] = new Field("", "PROCEDURE_SCHEM", "TEXT");
      fields[2] = new Field("", "PROCEDURE_NAME", "TEXT");
      fields[3] = new Field("", "COLUMN_NAME", "TEXT");
      fields[4] = new Field("", "COLUMN_TYPE", "TEXT");
      fields[5] = new Field("", "DATA_TYPE", "INT32");
      fields[6] = new Field("", "TYPE_NAME", "TEXT");
      fields[7] = new Field("", "PRECISION", "TEXT");
      fields[8] = new Field("", "LENGTH", "TEXT");
      fields[9] = new Field("", "SCALE", "TEXT");
      fields[10] = new Field("", "RADIX", "TEXT");
      fields[11] = new Field("", "NULLABLE", "TEXT");
      fields[12] = new Field("", "REMARKS", "TEXT");
      fields[13] = new Field("", "COLUMN_DEF", "TEXT");
      fields[14] = new Field("", "SQL_DATA_TYPE", "INT32");
      fields[15] = new Field("", "SQL_DATETIME_SUB", "TEXT");
      fields[16] = new Field("", "CHAR_OCTET_LENGTH", "TEXT");
      fields[17] = new Field("", "ORDINAL_POSITION", "TEXT");
      fields[18] = new Field("", "IS_NULLABLE", "TEXT");
      fields[19] = new Field("", "SPECIFIC_NAME", "TEXT");
      for (int i = 0; i < fields.length; i++) {
        columnNameList.add(fields[i].getName());
        columnTypeList.add(fields[i].getSqlType());
        columnNameIndex.put(fields[i].getName(), i);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      close(null, stmt);
    }
    return new IoTDBJDBCResultSet(
        stmt,
        columnNameList,
        columnTypeList,
        columnNameIndex,
        false,
        client,
        null,
        -1,
        sessionId,
        null,
        null,
        (long) 60 * 1000,
        false);
  }
}