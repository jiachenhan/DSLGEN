public class foo {
  /**
   * Start a worker, creating a holder for it. If a worker with this query ID is already started, does nothing.
   * Returns the worker.
   *
   * @throws DruidException if the controllerId does not correspond to a currently-active controller
   */
  public Worker startWorker(
      final String queryId,
      final String controllerHost,
      final QueryContext context
  )
  {
    final WorkerHolder holder;
    final boolean newHolder;

    synchronized (this) {
      if (!activeControllerHosts.contains(controllerHost)) {
        throw DruidException.forPersona(DruidException.Persona.OPERATOR)
                            .ofCategory(DruidException.Category.RUNTIME_FAILURE)
                            .build("Received startWorker request for unknown controller[%s]", controllerHost);
      }

      final WorkerHolder existingHolder = workerMap.get(queryId);
      if (existingHolder != null) {
        holder = existingHolder;
        newHolder = false;
      } else {
        final Worker worker = workerFactory.build(queryId, controllerHost, baseTempDir, context);
        final WorkerResource resource = new WorkerResource(worker, permissionMapper, authorizerMapper);
        holder = new WorkerHolder(worker, controllerHost, resource, DateTimes.nowUtc());
        workerMap.put(queryId, holder);
        this.notifyAll();
        newHolder = true;
      }
    }

    if (newHolder) {
      workerExec.submit(() -> {
        final String originalThreadName = Thread.currentThread().getName();
        try {
          Thread.currentThread().setName(StringUtils.format("%s[%s]", originalThreadName, queryId));
          holder.worker.run();
        }
        catch (Throwable t) {
          if (Thread.interrupted() || MSQFaultUtils.isCanceledException(t)) {
            log.debug(t, "Canceled, exiting thread.");
          } else {
            log.warn(t, "Worker for query[%s] failed and stopped.", queryId);
          }
        }
        finally {
          synchronized (this) {
            workerMap.remove(queryId, holder);
            this.notifyAll();
          }

          Thread.currentThread().setName(originalThreadName);
        }
      });
    }

    return holder.worker;
  }
}