public class foo {
    private static void updateVariableData(@NonNull Context context, @NonNull List<App> modifiedApps) {
        UriManager uriManager = new UriManager();
        ArrayMap<Integer, SsaidSettings> userIdSsaidSettingsMap = new ArrayMap<>();
        List<PackageUsageInfo> packageUsageInfoList = new ArrayList<>();
        boolean hasUsageAccess = FeatureController.isUsageAccessEnabled() && SelfPermissions.checkUsageStatsPermission();
        for (int userId : Users.getUsersIds()) {
            // Interrupt thread on request
            if (ThreadUtils.isInterrupted()) return;
            if (hasUsageAccess) {
                List<PackageUsageInfo> usageInfoList = ExUtils.exceptionAsNull(() -> AppUsageStatsManager.getInstance()
                        .getUsageStats(UsageUtils.USAGE_WEEKLY, userId));
                if (usageInfoList != null) {
                    packageUsageInfoList.addAll(usageInfoList);
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    userIdSsaidSettingsMap.put(userId, new SsaidSettings(userId));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        for (App app : modifiedApps) {
            if (!app.isInstalled && !app.isSystemApp()) {
                continue;
            }
            int userId = app.userId;
            try (ComponentsBlocker cb = ComponentsBlocker.getInstance(app.packageName, userId, false)) {
                app.rulesCount = cb.entryCount();
            }
            app.codeSize = app.dataSize = 0;
            if (hasUsageAccess) {
                PackageSizeInfo sizeInfo = PackageUtils.getPackageSizeInfo(context, app.packageName, userId, null);
                if (sizeInfo != null) {
                    app.codeSize = sizeInfo.codeSize + sizeInfo.obbSize;
                    app.dataSize = sizeInfo.dataSize + sizeInfo.mediaSize + sizeInfo.cacheSize;
                }
            }
            // Interrupt thread on request
            if (ThreadUtils.isInterrupted()) return;
            if (!app.isInstalled) {
                continue;
            }
            app.hasKeystore = KeyStoreUtils.hasKeyStore(app.uid);
            app.usesSaf = uriManager.getGrantedUris(app.packageName) != null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                SsaidSettings ssaidSettings = userIdSsaidSettingsMap.get(userId);
                if (ssaidSettings != null) {
                    String ssaid = ssaidSettings.getSsaid(app.packageName, app.uid);
                    app.ssaid = TextUtils.isEmpty(ssaid) ? null : ssaid;
                } else {
                    app.ssaid = null;
                }
            }
            PackageUsageInfo usageInfo = findUsage(packageUsageInfoList, app.packageName, userId);
            if (usageInfo != null) {
                app.mobileDataUsage = usageInfo.mobileData != null ? usageInfo.mobileData.getTotal() : 0;
                app.wifiDataUsage = usageInfo.wifiData != null ? usageInfo.wifiData.getTotal() : 0;
                app.openCount = usageInfo.timesOpened;
                app.screenTime = usageInfo.screenTime;
                app.lastUsageTime = usageInfo.lastUsageTime;
            } else {
                app.mobileDataUsage = app.wifiDataUsage = app.screenTime = app.lastUsageTime = 0;
                app.openCount = 0;
            }
        }
    }
}