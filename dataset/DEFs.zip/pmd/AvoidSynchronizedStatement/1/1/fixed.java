public class foo {
  /** Sync all volatile nodes to schemaFile and execute memory release after flush. */
  private void tryFlushVolatileNodes() {
    long startTime = System.currentTimeMillis();
    CompletableFuture.allOf(
            storeList.stream()
                .map(
                    store ->
                        CompletableFuture.runAsync(
                            () -> {
                              store.getLock().writeLock();
                              try {
                                store.flushVolatileNodes();
                                executeMemoryRelease(store);
                              } finally {
                                store.getLock().unlockWrite();
                              }
                            },
                            flushTaskProcessor))
                .toArray(CompletableFuture[]::new))
        .join();
    if (engineMetric != null) {
      engineMetric.recordFlush(System.currentTimeMillis() - startTime);
    }
    synchronized (blockObject) {
      hasFlushTask = false;
      blockObject.notifyAll();
    }
  }
}