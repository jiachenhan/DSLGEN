public class foo {
    @Override
    public final void onMessage(byte[] message) {
        ClassLoader tccl = Thread.currentThread()
            .getContextClassLoader();
        try {
            Object instance = parseSingleMessage(message);
            listener.onMessage(instance);
        } catch (Throwable t) {
            final TriRpcStatus status = TriRpcStatus.UNKNOWN.withDescription("Server error")
                .withCause(t);
            close(status, null);
            LOGGER.error(PROTOCOL_FAILED_REQUEST,"","","Process request failed. service=" + serviceName +
                " method=" + methodName, t);
        } finally {
            ClassLoadUtil.switchContextLoader(tccl);
        }
    }
}