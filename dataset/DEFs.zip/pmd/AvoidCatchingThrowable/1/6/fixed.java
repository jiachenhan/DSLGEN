public class foo {
    @Test
    public void testCreateGroup() {
        com.box.sdk.BoxGroup result = null;

        try {
            // using String message body for single parameter "name"
            result = requestBody("direct://CREATEGROUP", CAMEL_TEST_CREATE_GROUP_NAME);
            assertNotNull(result, "createGroup result");
            assertEquals(CAMEL_TEST_CREATE_GROUP_NAME, result.getInfo().getName());
            LOG.debug("createGroup: {}", result);
        } finally {
            if (result != null) {
                try {
                    result.delete();
                } catch (Exception t) {
                }
            }
        }
    }
}