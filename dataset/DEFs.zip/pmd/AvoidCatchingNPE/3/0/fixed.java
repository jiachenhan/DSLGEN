public class foo {
  public void testCheckNotNull_simple_failure() {
    assertThrows(NullPointerException.class, () -> checkNotNull(null));
  }
}