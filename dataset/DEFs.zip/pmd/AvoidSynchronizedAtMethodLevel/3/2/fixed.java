public class foo {
    public void remove(Video video) {
        if (mVideos == null) {
            return;
        }

        try {
            mVideos.remove(video);
        } catch (UnsupportedOperationException e) { // read only collection
            e.printStackTrace();
        }
    }
}