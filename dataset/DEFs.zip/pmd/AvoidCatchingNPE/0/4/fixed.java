public class foo {
  public void testOf_null() {
    assertThrows(NullPointerException.class, () -> Optional.of(null));
  }
}