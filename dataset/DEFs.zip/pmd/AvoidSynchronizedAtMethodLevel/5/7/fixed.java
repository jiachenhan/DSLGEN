public class foo {
  /** Deletes a key in Android Keystore. */
  public void deleteKey(String keyUri) throws GeneralSecurityException {
    String keyId = Validators.validateKmsKeyUriAndRemovePrefix(PREFIX, keyUri);
    synchronized (keystoreLock) {
      getAndroidKeyStore().deleteEntry(keyId);
    }
  }
}