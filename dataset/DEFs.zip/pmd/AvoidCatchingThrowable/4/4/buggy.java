public class foo {
  public void startCQScheduler() {
    lock.writeLock().lock();
    try {
      // 1. shutdown previous cq schedule thread pool
      try {
        if (executor != null) {
          executor.shutdown();
        }
      } catch (Throwable t) {
        // just print the error log because we should make sure we can start a new cq schedule pool
        // successfully in the next steps
        LOGGER.error("Error happened while shutting down previous cq schedule thread pool.", t);
      }

      // 2. start a new schedule thread pool
      executor =
          IoTDBThreadPoolFactory.newScheduledThreadPool(CONF.getCqSubmitThread(), "CQ-Scheduler");

      // 3. get all CQs
      List<CQInfo.CQEntry> allCQs = null;
      // wait for consensus layer ready
      while (configManager.getConsensusManager() == null) {
        try {
          LOGGER.info("consensus layer is not ready, sleep 1s...");
          TimeUnit.SECONDS.sleep(1);
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
          LOGGER.warn("Unexpected interruption during waiting for consensus layer ready.");
        }
      }
      // keep fetching until we get all CQEntries if this node is still leader
      while (allCQs == null && configManager.getConsensusManager().isLeader()) {
        ConsensusReadResponse response = configManager.getConsensusManager().read(new ShowCQPlan());
        if (response.getDataset() != null) {
          allCQs = ((ShowCQResp) response.getDataset()).getCqList();
        } else {
          // consensus layer related errors
          LOGGER.warn(
              "Unexpected error happened while fetching cq list: ", response.getException());
        }
      }

      // 4. recover the scheduling of active CQs
      if (allCQs != null) {
        for (CQInfo.CQEntry entry : allCQs) {
          if (entry.getState() == CQState.ACTIVE) {
            CQScheduleTask cqScheduleTask = new CQScheduleTask(entry, executor, configManager);
            cqScheduleTask.submitSelf();
          }
        }
      }

    } finally {
      lock.writeLock().unlock();
    }
  }
}