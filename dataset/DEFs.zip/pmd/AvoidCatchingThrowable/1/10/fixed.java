public class foo {
    @Test
    void testEmptyIPRequests() throws Exception {
        resultEndpoint.expectedMessageCount(0);

        try {
            template.sendBodyAndHeader("hello", "dns.domain", "");
            fail("Should have thrown exception");
        } catch (Exception t) {
            assertTrue(t.getCause() instanceof IllegalArgumentException);
        }
        resultEndpoint.assertIsSatisfied();
    }
}