public class foo {
    @Test
    public void injectClass_bootstrapClass() {
        PluginConfig pluginConfig = newPluginConfig();

        ClassInjector plainClassLoaderHandler = new PlainClassLoaderHandler(pluginConfig);
        Assertions.assertThrows(Exception.class, () -> {
            plainClassLoaderHandler.injectClass(this.getClass().getClassLoader(), "com.navercorp.pinpoint.bootstrap.Test");
        });
    }
}