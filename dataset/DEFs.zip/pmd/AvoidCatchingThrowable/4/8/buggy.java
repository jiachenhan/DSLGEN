public class foo {
    /**
     * Aggregates the exchange with the given correlation key
     * <p/>
     * This method <b>must</b> be run synchronized as we cannot aggregate the same correlation key in parallel.
     * <p/>
     * The returned {@link Exchange} should be send downstream using the
     * {@link #onSubmitCompletion(String, org.apache.camel.Exchange)} method which sends out the aggregated and
     * completed {@link Exchange}.
     *
     * @param  key                                     the correlation key
     * @param  newExchange                             the exchange
     * @return                                         the aggregated exchange(s) which is complete, or <tt>null</tt> if
     *                                                 not yet complete
     * @throws org.apache.camel.CamelExchangeException is thrown if error aggregating
     */
    private List<Exchange> doAggregation(String key, Exchange newExchange) throws CamelExchangeException {
        LOG.trace("onAggregation +++ start +++ with correlation key: {}", key);

        List<Exchange> list = new ArrayList<>();
        String complete = null;

        Exchange answer;
        Exchange originalExchange = aggregationRepository.get(newExchange.getContext(), key);
        Exchange oldExchange = originalExchange;

        Integer size = 1;
        if (oldExchange != null) {
            // hack to support legacy AggregationStrategy's that modify and return the oldExchange, these will not
            // working when using an identify based approach for optimistic locking like the MemoryAggregationRepository.
            if (optimisticLocking && aggregationRepository instanceof MemoryAggregationRepository) {
                oldExchange = originalExchange.copy();
            }
            size = oldExchange.getProperty(ExchangePropertyKey.AGGREGATED_SIZE, 0, Integer.class);
            size++;
        }

        // prepare the exchanges for aggregation
        ExchangeHelper.prepareAggregation(oldExchange, newExchange);

        // check if we are pre complete
        if (preCompletion) {
            try {
                // put the current aggregated size on the exchange so its avail during completion check
                newExchange.setProperty(ExchangePropertyKey.AGGREGATED_SIZE, size);
                newExchange.setProperty(ExchangePropertyKey.AGGREGATED_CORRELATION_KEY, key);
                complete = isPreCompleted(key, oldExchange, newExchange);
                // make sure to track timeouts if not complete
                if (complete == null) {
                    trackTimeout(key, newExchange);
                }
                // remove it afterwards
                newExchange.removeProperty(ExchangePropertyKey.AGGREGATED_SIZE);
                newExchange.removeProperty(ExchangePropertyKey.AGGREGATED_CORRELATION_KEY);
            } catch (Throwable e) {
                // must catch any exception from aggregation
                throw new CamelExchangeException("Error occurred during preComplete", newExchange, e);
            }
        } else if (isEagerCheckCompletion()) {
            // put the current aggregated size on the exchange so its avail during completion check
            newExchange.setProperty(ExchangePropertyKey.AGGREGATED_SIZE, size);
            newExchange.setProperty(ExchangePropertyKey.AGGREGATED_CORRELATION_KEY, key);
            complete = isCompleted(key, newExchange);
            // make sure to track timeouts if not complete
            if (complete == null) {
                trackTimeout(key, newExchange);
            }
            // remove it afterwards
            newExchange.removeProperty(ExchangePropertyKey.AGGREGATED_SIZE);
            newExchange.removeProperty(ExchangePropertyKey.AGGREGATED_CORRELATION_KEY);
        }

        if (preCompletion && complete != null) {
            // need to pre complete the current group before we aggregate
            doAggregationComplete(complete, list, key, originalExchange, oldExchange, false);
            // as we complete the current group eager, we should indicate the new group is not complete
            complete = null;
            // and clear old/original exchange as we start on a new group
            oldExchange = null;
            originalExchange = null;
            // and reset the size to 1
            size = 1;
            // make sure to track timeout as we just restart the correlation group when we are in pre completion mode
            trackTimeout(key, newExchange);
        }

        // aggregate the exchanges
        boolean aggregateFailed = false;
        try {
            answer = onAggregation(oldExchange, newExchange);
        } catch (Throwable e) {
            aggregateFailed = true;
            if (isDiscardOnAggregationFailure()) {
                // discard due failure in aggregation strategy
                LOG.debug(
                        "Aggregation for correlation key {} discarding aggregated exchange: {} due to failure in AggregationStrategy caused by: {}",
                        key, oldExchange, e.getMessage());
                complete = COMPLETED_BY_STRATEGY;
                answer = oldExchange;
                if (answer == null) {
                    // first message in group failed during aggregation and we should just discard this
                    return null;
                }
            } else {
                // must catch any exception from aggregation
                throw new CamelExchangeException("Error occurred during aggregation", newExchange, e);
            }
        }
        if (answer == null) {
            throw new CamelExchangeException(
                    "AggregationStrategy " + aggregationStrategy + " returned null which is not allowed", newExchange);
        }

        // check for the special exchange property to force completion of all groups
        if (isCompleteAllGroups(answer)) {
            removeFlagCompleteAllGroups(answer);
            forceCompletionOfAllGroups();
        } else if (isCompletionOnNewCorrelationGroup() && originalExchange == null) {
            // its a new group so force complete of all existing groups
            forceCompletionOfAllGroups();
        }

        // special for some repository implementations
        if (isRecoverableRepository()) {
            boolean valid = oldExchange == null || answer.getExchangeId().equals(oldExchange.getExchangeId());
            if (!valid && aggregateRepositoryWarned.compareAndSet(false, true)) {
                LOG.warn(
                        "AggregationStrategy should return the oldExchange instance instead of the newExchange whenever possible"
                         + " as otherwise this can lead to unexpected behavior with some RecoverableAggregationRepository implementations");
            }
        }

        // update the aggregated size
        answer.setProperty(ExchangePropertyKey.AGGREGATED_SIZE, size);

        // maybe we should check completion after the aggregation
        if (!preCompletion && !isEagerCheckCompletion()) {
            complete = isCompleted(key, answer);
            // make sure to track timeouts if not complete
            if (complete == null) {
                trackTimeout(key, newExchange);
            }
        }

        if (!aggregateFailed && complete == null) {
            // only need to update aggregation repository if we are not complete
            doAggregationRepositoryAdd(newExchange.getContext(), key, originalExchange, answer);
        } else {
            // if we are complete then add the answer to the list
            doAggregationComplete(complete, list, key, originalExchange, answer, aggregateFailed);
        }

        LOG.trace("onAggregation +++  end  +++ with correlation key: {}", key);
        return list;
    }
}