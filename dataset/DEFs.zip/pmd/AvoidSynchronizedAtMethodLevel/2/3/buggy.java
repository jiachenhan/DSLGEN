public class foo {
  public synchronized void stopAllPipesWithCriticalException() {
    acquireWriteLock();
    try {
      stopAllPipesWithCriticalExceptionInternal();
    } finally {
      releaseWriteLock();
    }
  }
}