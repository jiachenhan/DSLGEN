public class foo {
    /**
     * A multithreaded test for IdempotentConsumer filter
     */
    @Test
    public void testThreadedIdempotentConsumer() throws Exception {
        final int loopCount = 100;
        final int threadCount = 10;

        context.addRoutes(new RouteBuilder() {
            @Override
            public void configure() throws Exception {
                from("direct:start")
                        .idempotentConsumer(header("messageId"), MemoryIdempotentRepository.memoryIdempotentRepository(200))
                        .delay(1).to("mock:result");
            }
        });
        context.start();

        resultEndpoint.reset();
        resultEndpoint.expectedMessageCount(loopCount);

        final boolean failedFlag[] = new boolean[1];
        failedFlag[0] = false;

        Thread[] threads = new Thread[threadCount];
        for (int i = 0; i < threadCount; i++) {
            final int threadIndex = i;
            threads[threadIndex] = new Thread() {
                @Override
                public void run() {
                    try {
                        for (int j = 0; j < loopCount; j++) {
                            sendMessage(String.valueOf(j), "multithreadedTest" + j);
                        }
                    } catch (Exception e) {
                        LOG.error("Failed to send message: {}", e.getMessage(), e);
                        failedFlag[0] = true;
                    }
                }
            };
            threads[i].start();
        }
        for (int i = 0; i < threadCount; i++) {
            threads[i].join();
        }
        assertFalse(failedFlag[0], "At least one thread threw an exception");

        assertMockEndpointsSatisfied();
    }
}