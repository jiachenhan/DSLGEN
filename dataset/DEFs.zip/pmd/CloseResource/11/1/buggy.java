public class foo {
  /**
   * Serialize the user object to a temp file, then replace the old user file with the new file.
   *
   * @param user The user object that is to be saved.
   */
  @Override
  public void saveUser(User user) throws IOException {
    File userProfile =
        SystemFileFactory.INSTANCE.getFile(
            userDirPath
                + File.separator
                + user.getName()
                + IoTDBConstant.PROFILE_SUFFIX
                + TEMP_SUFFIX);

    FileOutputStream fileOutputStream = new FileOutputStream(userProfile);
    BufferedOutputStream outputStream = new BufferedOutputStream(fileOutputStream);
    try {
      // for IOTDB 1.2, the username's length will be stored as a negative number.
      byte[] strBuffer = user.getName().getBytes(STRING_ENCODING);
      IOUtils.writeInt(outputStream, -1 * strBuffer.length, encodingBufferLocal);
      outputStream.write(strBuffer);
      IOUtils.writeString(outputStream, user.getPassword(), STRING_ENCODING, encodingBufferLocal);
      IOUtils.writeInt(outputStream, user.getAllSysPrivileges(), encodingBufferLocal);

      int privilegeNum = user.getPathPrivilegeList().size();
      for (int i = 0; i < privilegeNum; i++) {
        PathPrivilege pathPrivilege = user.getPathPrivilegeList().get(i);
        IOUtils.writePathPrivilege(
            outputStream, pathPrivilege, STRING_ENCODING, encodingBufferLocal);
      }

    } catch (Exception e) {
      throw new IOException(e);
    } finally {
      outputStream.flush();
      fileOutputStream.getFD().sync();
      outputStream.close();
      encodingBufferLocal.remove();
    }

    File roleProfile =
        SystemFileFactory.INSTANCE.getFile(
            userDirPath
                + File.separator
                + user.getName()
                + ROLE_SUFFIX
                + IoTDBConstant.PROFILE_SUFFIX
                + TEMP_SUFFIX);
    fileOutputStream = new FileOutputStream(roleProfile);
    outputStream = new BufferedOutputStream(fileOutputStream);
    try {
      int userNum = user.getRoleList().size();
      for (int i = 0; i < userNum; i++) {
        IOUtils.writeString(
            outputStream, user.getRoleList().get(i), STRING_ENCODING, encodingBufferLocal);
      }
    } catch (Exception e) {
      throw new IOException(e);
    } finally {
      outputStream.flush();
      fileOutputStream.getFD().sync();
      outputStream.close();
      encodingBufferLocal.remove();
    }

    File oldUserFile =
        SystemFileFactory.INSTANCE.getFile(
            userDirPath + File.separator + user.getName() + IoTDBConstant.PROFILE_SUFFIX);
    IOUtils.replaceFile(userProfile, oldUserFile);
    File oldURoleFile =
        SystemFileFactory.INSTANCE.getFile(
            userDirPath
                + File.separator
                + user.getName()
                + ROLE_SUFFIX
                + IoTDBConstant.PROFILE_SUFFIX);
    IOUtils.replaceFile(roleProfile, oldURoleFile);
  }
}