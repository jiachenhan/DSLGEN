public class foo {
	void checkin(CheckinHandler checkinHandler, boolean okToUpgrade, TaskMonitor monitor)
			throws IOException, VersionException, CancelledException {

		if (!versionedFileSystem.isOnline()) {
			throw new NotConnectedException("Not connected to repository server");
		}
		if (fileSystem.isReadOnly() || versionedFileSystem.isReadOnly()) {
			throw new ReadOnlyException(
				"checkin permitted within writeable project and repository only");
		}
		if (!isCheckedOut()) {
			throw new IOException("File not checked out");
		}
		if (isChanged()) {
			throw new IOException("File has unsaved changes");
		}
		if (canRecover()) {
			throw new IOException("File recovery data exists");
		}
		if (!modifiedSinceCheckout()) {
			throw new IOException("File has not been modified since checkout");
		}
		verifyRepoUser("checkin");
		if (monitor == null) {
			monitor = TaskMonitor.DUMMY;
		}
		synchronized (fileSystem) {
			if (busy) {
				throw new FileInUseException(name + " is busy");
			}
			busy = true;
		}
		try {
			boolean quickCheckin = ALWAYS_MERGE ? false : quickCheckin(checkinHandler, monitor);

			if (!quickCheckin) {

				if (SystemUtilities.isInHeadlessMode()) {
					throw new IOException(
						"Checkin failed, file requires merge which is not supported in headless mode");
				}

				Msg.info(this, "Checkin with merge for " + name);

				ContentHandler<?> ch = getContentHandler();
				DomainObjectAdapter checkinObj = ch.getDomainObject(versionedFolderItem, null,
					folderItem.getCheckoutId(), okToUpgrade, false, this, monitor);
				checkinObj.setDomainFile(new DomainFileProxy(name, getParent().getPathname(),
					checkinObj, versionedFolderItem.getCurrentVersion() + 1, fileID,
					parent.getProjectLocator()));

				DomainObject sourceObj = null;
				DomainObject originalObj = null;
				DomainObject latestObj = null;
				try {
					synchronized (fileSystem) {
						int coVer = folderItem.getCheckoutVersion();
						sourceObj = ch.getImmutableObject(folderItem, this,
							DomainFile.DEFAULT_VERSION, -1, monitor);
						originalObj =
							ch.getImmutableObject(versionedFolderItem, this, coVer, -1, monitor);
						latestObj = ch.getImmutableObject(versionedFolderItem, this,
							DomainFile.DEFAULT_VERSION, coVer, monitor);
					}
					DomainObjectMergeManager mergeMgr =
						ch.getMergeManager(checkinObj, sourceObj, originalObj, latestObj);

					if (!mergeMgr.merge(monitor)) {
						Msg.info(this, "Checkin with merge terminated for " + name);
						return; // error displayed by merge manager
					}

					checkinObj.save(checkinHandler.getComment(), monitor);

					if (checkinHandler.createKeepFile()) {
						if (monitor != null) {
							monitor.setMessage("Generating local keep file...");
						}
						createKeepFile(sourceObj, monitor);
					}

				}
				finally {
					checkinObj.release(this);
					if (sourceObj != null) {
						sourceObj.release(this);
					}
					if (originalObj != null) {
						originalObj.release(this);
					}
					if (latestObj != null) {
						latestObj.release(this);
					}
				}
			}

			DomainObjectAdapter oldDomainObj = null;

			FolderItem oldLocalItem = null;
			boolean keepCheckedOut = checkinHandler.keepCheckedOut();

			synchronized (fileSystem) {

				oldDomainObj = getOpenedDomainObject();

				versionedFolderItem = versionedFileSystem.getItem(parent.getPathname(), name);
				if (versionedFolderItem == null) {
					throw new IOException("Checkin failed, versioned item not found");
				}

				Msg.info(this, "Checkin completed for " + name);

				if (keepCheckedOut) {
					boolean success = false;
					try {
						if (monitor != null) {
							monitor.setMessage("Updating local checkout file...");
						}
						folderItem.updateCheckout(versionedFolderItem, !quickCheckin, monitor);
						success = true;
					}
					finally {
						if (!success) {
							try {
								undoCheckout(false, true);
							}
							catch (IOException e) {
								Msg.error(this, "Undo checkout error", e);
							}
						}
					}
				}
				else {
					if (oldDomainObj != null) {
						oldLocalItem = folderItem;
						folderItem = null;
					}
					else {
						undoCheckout(false, true);
					}
				}
				if (oldDomainObj != null) {

					// TODO: Develop way to re-use and re-init domain object instead of a switch-a-roo approach

					fileManager.clearDomainObject(getPathname());

					oldDomainObj.setDomainFile(new DomainFileProxy(name, parent.getPathname(),
						oldDomainObj, -2, fileID, parent.getProjectLocator())); // invalid version (-2) specified to avoid file match
					oldDomainObj.setTemporary(true);
				}
			}

			if (oldDomainObj != null) {
				// complete re-open of domain file
				DomainFile df = getDomainFile();
				listener.domainFileObjectClosed(df, oldDomainObj);
				listener.domainFileObjectReplaced(df, oldDomainObj);
			}

			if (oldLocalItem != null) {
				synchronized (fileSystem) {
					// Undo checkout of old item - this will fail on Windows if item is open
					long checkoutId = oldLocalItem.getCheckoutId();
					oldLocalItem.delete(-1, ClientUtil.getUserName());
					versionedFolderItem.terminateCheckout(checkoutId, true);
				}
			}
		}
		finally {
			busy = false;
			parent.deleteLocalFolderIfEmpty();
			parent.fileChanged(name);
		}

	}
}