public class foo {
    public void clear() {
        synchronized (this) {
            value = null;
        }
    }
}