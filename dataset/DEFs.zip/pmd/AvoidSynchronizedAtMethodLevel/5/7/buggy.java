public class foo {
  /** Deletes a key in Android Keystore. */
  public synchronized void deleteKey(String keyUri) throws GeneralSecurityException {
    String keyId = Validators.validateKmsKeyUriAndRemovePrefix(PREFIX, keyUri);
    getAndroidKeyStore().deleteEntry(keyId);
  }
}