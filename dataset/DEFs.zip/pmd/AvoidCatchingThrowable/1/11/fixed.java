public class foo {
    private void deleteTestGroup() {
        if (testGroup != null) {
            try {
                testGroup.delete();
            } catch (Exception t) {
            }
            testGroup = null;
        }
    }
}