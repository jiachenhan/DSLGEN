public class foo {
    @Override
    public boolean process(final Exchange exchange, final AsyncCallback callback) {
        // properties for method arguments should let exchange override
        final Map<String, Object> properties = new HashMap<>();
        properties.putAll(endpoint.getConfigurationProperties());
        properties.putAll(endpoint.getEndpointProperties());
        propertiesHelper.getExchangeProperties(exchange, properties);

        // let the endpoint and the Producer intercept properties
        endpoint.interceptProperties(properties);
        interceptProperties(properties);

        // decide which method to invoke
        final ApiMethod method = findMethod(exchange, properties);
        if (method == null) {
            // synchronous failure
            callback.done(true);
            return true;
        }

        // create a runnable invocation task to be submitted on a background thread pool
        // this way we avoid blocking the current thread for long running methods
        Runnable invocation = new Runnable() {
            @Override
            public void run() {
                try {
                    if (log.isDebugEnabled()) {
                        log.debug("Invoking operation {} with {}", method.getName(), properties.keySet());
                    }

                    Object result = doInvokeMethod(method, properties);

                    // producer returns a single response, even for methods with List return types
                    exchange.getMessage().setBody(result);

                    interceptResult(result, exchange);

                } catch (Throwable t) {
                    exchange.setException(RuntimeCamelException.wrapRuntimeCamelException(t));
                } finally {
                    callback.done(false);
                }
            }
        };

        endpoint.getExecutorService().submit(invocation);
        return false;
    }
}