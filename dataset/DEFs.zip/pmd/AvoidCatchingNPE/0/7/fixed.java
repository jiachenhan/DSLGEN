public class foo {
  @SuppressWarnings("SelfComparison")
  public void testGet_comparable() {
    @SuppressWarnings("unchecked") // The null value can compare with any Object
    Comparable<Object> comparable = ArbitraryInstances.get(Comparable.class);
    assertEquals(0, comparable.compareTo(comparable));
    assertTrue(comparable.compareTo("") > 0);
    assertThrows(NullPointerException.class, () -> comparable.compareTo(null));
  }
}