public class foo {
    @Override
    public boolean validatePerColumnIndexComponents(IndexDescriptor indexDescriptor, IndexContext indexContext, boolean checksum)
    {
        for (IndexComponent indexComponent : perColumnIndexComponents(indexContext))
        {
            if (isNotBuildCompletionMarker(indexComponent))
            {
                try (IndexInput input = indexDescriptor.openPerIndexInput(indexComponent, indexContext))
                {
                    if (checksum)
                        SAICodecUtils.validateChecksum(input);
                    else
                        SAICodecUtils.validate(input);
                }
                catch (Throwable e)
                {
                    if (logger.isDebugEnabled())
                    {
                        logger.debug(indexDescriptor.logMessage("{} failed for index component {} on SSTable {}"),
                                     (checksum ? "Checksum validation" : "Validation"),
                                     indexComponent,
                                     indexDescriptor.sstableDescriptor);
                    }
                    return false;
                }
            }
        }
        return true;
    }
}