public class foo {
  private void onEnd() {
    boolean tryClose;
    Http1xServerRequest request;
    synchronized (this) {
      request = requestInProgress;
      requestInProgress = null;
      tryClose = wantClose && responseInProgress == null;
    }
    request.context.execute(request, Http1xServerRequest::handleEnd);
    if (tryClose) {
      if (shutdownTimerID != -1L) {
        if (!vertx.cancelTimer(shutdownTimerID)) {
          return;
        }
        shutdownTimerID = -1L;
      }
      flushAndClose();
    }
  }
}