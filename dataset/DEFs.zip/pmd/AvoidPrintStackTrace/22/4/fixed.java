public class foo {
    private Long getLock(Long dataSourceId, String databaseName, String schemaName, TableCacheVersionDO versionDO) {
        String key = getTableKey(dataSourceId, databaseName, schemaName);
        if (versionDO == null) {
            versionDO = new TableCacheVersionDO();
            versionDO.setDatabaseName(databaseName);
            versionDO.setSchemaName(schemaName);
            versionDO.setDataSourceId(dataSourceId);
            versionDO.setStatus("2");
            versionDO.setKey(key);
            versionDO.setVersion(0L);
            versionDO.setTableCount(0L);
            try {
                getVersionMapper().insert(versionDO);
                return 0L;
            } catch (Exception e) {
                log.error("getLock error", e);
                return -1L;
            }
        } else {
            long version = versionDO.getVersion() + 1;
            LambdaQueryWrapper<TableCacheVersionDO> queryWrapper = new LambdaQueryWrapper();
            queryWrapper.eq(TableCacheVersionDO::getId, versionDO.getId());
            queryWrapper.eq(TableCacheVersionDO::getVersion, versionDO.getVersion());
            versionDO.setVersion(version);
            versionDO.setStatus("2");
            int n = getVersionMapper().update(versionDO, queryWrapper);
            if (n == 1) {
                return version;
            } else {
                return -1L;
            }
        }
    }
}