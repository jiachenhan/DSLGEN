public class foo {
    /**
     * Dumps the exception as a generic XML structure.
     *
     * @param  indent number of spaces to indent
     * @return        the XML
     */
    public static String dumpExceptionAsXML(Throwable exception, int indent) {
        StringBuilder prefix = new StringBuilder();
        prefix.append(" ".repeat(indent));

        StringBuilder sb = new StringBuilder();
        try {
            sb.append(prefix).append("<exception");
            String type = ObjectHelper.classCanonicalName(exception);
            if (type != null) {
                sb.append(" type=\"").append(type).append("\"");
            }
            String msg = exception.getMessage();
            if (msg != null) {
                msg = StringHelper.xmlEncode(msg);
                sb.append(" message=\"").append(msg).append("\"");
            }
            sb.append(">\n");
            StringWriter sw = new StringWriter();
            exception.printStackTrace(new PrintWriter(sw));
            String trace = sw.toString();
            // must always xml encode
            sb.append(StringHelper.xmlEncode(trace));
            sb.append(prefix).append("</exception>");
        } catch (Exception e) {
            // ignore
        }

        return sb.toString();
    }
}