public class foo {
    /**
     * Common work which must be done when we are done multicasting.
     * <p/>
     * This logic applies for both running synchronous and asynchronous as there are multiple exist points when using
     * the asynchronous routing engine. And therefore we want the logic in one method instead of being scattered.
     *
     * @param original     the original exchange
     * @param subExchange  the current sub exchange, can be <tt>null</tt> for the synchronous part
     * @param pairs        the pairs with the exchanges to process
     * @param callback     the callback
     * @param doneSync     the <tt>doneSync</tt> parameter to call on callback
     * @param forceExhaust whether error handling is exhausted
     */
    protected void doDone(
            Exchange original, Exchange subExchange, final Iterable<ProcessorExchangePair> pairs,
            AsyncCallback callback, boolean doneSync, boolean forceExhaust) {

        AggregationStrategy strategy = getAggregationStrategy(subExchange);
        // invoke the on completion callback
        if (strategy != null) {
            strategy.onCompletion(subExchange, original);
        }

        // cleanup any per exchange aggregation strategy
        removeAggregationStrategyFromExchange(original);

        // we need to know if there was an exception, and if the stopOnException option was enabled
        // also we would need to know if any error handler has attempted redelivery and exhausted
        boolean stoppedOnException = false;
        boolean exception = false;
        boolean exhaust = forceExhaust || subExchange != null
                && (subExchange.getException() != null || subExchange.getExchangeExtension().isRedeliveryExhausted());
        if (original.getException() != null || subExchange != null && subExchange.getException() != null) {
            // there was an exception and we stopped
            stoppedOnException = isStopOnException();
            exception = true;
        }

        // must copy results at this point
        if (subExchange != null) {
            if (stoppedOnException) {
                // if we stopped due an exception then only propagate the exception
                original.setException(subExchange.getException());
            } else {
                // copy the current result to original (preserve original correlation id),
                // so it will contain this result of this eip
                Object correlationId = original.removeProperty(ExchangePropertyKey.CORRELATION_ID);
                ExchangeHelper.copyResults(original, subExchange);
                if (correlationId != null) {
                    original.setProperty(ExchangePropertyKey.CORRELATION_ID, correlationId);
                }
            }
        }

        if (processorExchangeFactory != null && pairs != null) {
            // the exchanges on the pairs was created with a factory, so they should be released
            try {
                for (ProcessorExchangePair pair : pairs) {
                    processorExchangeFactory.release(pair.getExchange());
                }
            } catch (Throwable e) {
                LOG.warn("Error releasing exchange due to {}. This exception is ignored.", e.getMessage(), e);
            }
        }
        // we are done so close the pairs iterator
        if (pairs instanceof Closeable) {
            IOHelper.close((Closeable) pairs, "pairs", LOG);
        }

        // .. and then if there was an exception we need to configure the redelivery exhaust
        // for example the noErrorHandler will not cause redelivery exhaust so if this error
        // handled has been in use, then the exhaust would be false (if not forced)
        if (exception) {
            // multicast uses error handling on its output processors and they have tried to redeliver
            // so we shall signal back to the other error handlers that we are exhausted and they should not
            // also try to redeliver as we would then do that twice
            original.getExchangeExtension().setRedeliveryExhausted(exhaust);
        }

        reactiveExecutor.schedule(callback);
    }
}