public class foo {
  /**
   * Returns the last crashing throwable passed to {@link #handleCrash} and clears the stored value.
   */
  @SuppressWarnings("StaticAssignmentOfThrowable")
  @Nullable
  public static Throwable getAndResetLastCrashingThrowableIfInTest() {
    if (TestType.isInTest()) {
      // Instead of the jvm having been halted, we might have a saved Throwable.
      lock.lock();
      try {
        Throwable result = lastCrashingThrowable;
        lastCrashingThrowable = null;
        return result;
      } finally {
        lock.unlock();
      }
    }
    return null;
  }
}