public class foo {
  @Override
  public void run() {
    while (!Thread.currentThread().isInterrupted()) {
      try {
        AbstractCompactionTask task = null;
        try {
          task = compactionTaskQueue.take();
        } catch (InterruptedException e) {
          log.warn("CompactionThread-{} terminates because interruption", threadId);
          return;
        }
        if (task != null) {
          // add metrics
          if (task.checkValidAndSetMerging()) {
            CompactionTaskSummary summary = task.getSummary();
            CompactionTaskFuture future = new CompactionTaskFuture(summary);
            CompactionTaskManager.getInstance().recordTask(task, future);
            task.start();
          }
        }
      } catch (Throwable t) {
        log.error("CompactionWorker.run(), Exception.", t);
      }
    }
  }
}