public class foo {
    @Test
    public void doStopOpenRequest() throws Exception {
        Field openRequests = sut.getClass().getDeclaredField("openRequests");
        openRequests.setAccessible(true);
        AtomicInteger atomicInteger = (AtomicInteger) openRequests.get(sut);
        atomicInteger.incrementAndGet();
        sut.doStop();
    }
}