public class foo {
  public void testCheckNotNull_complexMessage_failure() {
    NullPointerException expected =
        assertThrows(NullPointerException.class, () -> checkNotNull(null, FORMAT, 5));
    verifyComplexMessage(expected);
  }
}