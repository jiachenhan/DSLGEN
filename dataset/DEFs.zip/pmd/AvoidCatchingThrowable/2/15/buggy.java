public class foo {
    @SuppressWarnings("unchecked")
    protected void onEvent(Exchange exchange, ExchangeEvent event, Breakpoint breakpoint) {
        // try to get the last known definition
        List<MessageHistory> list = exchange.getProperty(ExchangePropertyKey.MESSAGE_HISTORY, List.class);
        MessageHistory last = list != null ? list.get(list.size() - 1) : null;
        NamedNode definition = last != null ? last.getNode() : null;

        try {
            breakpoint.onEvent(exchange, event, definition);
        } catch (Throwable e) {
            // ignore
        }
    }
}