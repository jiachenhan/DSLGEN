public class foo {
  public void testNewReferenceArray_withNullArray() throws Exception {
    try {
      Atomics.newReferenceArray(null);
      fail();
    } catch (NullPointerException expected) {
    }
  }
}