public class foo {
	@Test
	@Disabled
	public void downloadFileFromUrlTest2() {
		File file = null;
		try {
			file = HttpDownloader.downloadFile("https://repo1.maven.org/maven2/cn/hutool/hutool-all/5.4.0/hutool-all-5.4.0-sources.jar", FileUtil.file("d:/download/temp"), 1, new StreamProgress() {
				@Override
				public void start() {
					System.out.println("start");
				}

				@Override
				public void progress(final long contentLength, final long progressSize) {
					System.out.println("download size:" + progressSize);
				}

				@Override
				public void finish() {
					System.out.println("end");
				}
			});

			Assertions.assertNotNull(file);
			Assertions.assertTrue(file.exists());
			Assertions.assertTrue(file.isFile());
			Assertions.assertTrue(file.length() > 0);
			Assertions.assertFalse(file.getName().isEmpty());
		} catch (final Exception e) {
			Assertions.assertInstanceOf(IORuntimeException.class, e);
		} finally {
			FileUtil.del(file);
		}
	}
}