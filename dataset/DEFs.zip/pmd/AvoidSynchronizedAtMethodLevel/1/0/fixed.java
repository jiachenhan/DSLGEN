public class foo {
  public void register(String id, Runnable periodicalJob, long intervalInSeconds) {
    periodicalJobs.add(
        new Pair<>(
            new WrappedRunnable() {
              @Override
              public void runMayThrow() {
                try {
                  periodicalJob.run();
                } catch (Exception e) {
                  LOGGER.warn("Periodical job {} failed.", id, e);
                }
              }
            },
            Math.max(intervalInSeconds / MIN_INTERVAL_SECONDS, 1)));
    LOGGER.info(
        "Pipe periodical job {} is registered successfully. Interval: {} seconds.",
        id,
        Math.max(intervalInSeconds / MIN_INTERVAL_SECONDS, 1) * MIN_INTERVAL_SECONDS);
  }
}