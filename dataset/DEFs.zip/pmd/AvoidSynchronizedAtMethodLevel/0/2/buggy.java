public class foo {
        synchronized void stop(StaticObject death) {
            KillStatus s = status;
            if (s.canStop()) {
                // Writing the throwable must be done before the kill status can be observed
                throwable = death;
                updateKillState(STOP);
            }
        }
}