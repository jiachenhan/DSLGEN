public class foo {
    @Fold
    static EnumSet<?> getStaticFeatures() {
        Architecture arch = ConfigurationValues.getTarget().arch;
        if (arch instanceof AMD64) {
            return ((AMD64) arch).getFeatures();
        } else if (arch instanceof AArch64) {
            return ((AArch64) arch).getFeatures();
        } else if (arch instanceof RISCV64) {
            return ((RISCV64) arch).getFeatures();
        } else {
            throw GraalError.shouldNotReachHere("unsupported architecture"); // ExcludeFromJacocoGeneratedReport
        }
    }
}