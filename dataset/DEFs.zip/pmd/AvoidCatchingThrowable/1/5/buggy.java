public class foo {
    private void deleteTestTask() {
        try {
            testTask.delete();
        } catch (Throwable t) {
        }
        testTask = null;
    }
}