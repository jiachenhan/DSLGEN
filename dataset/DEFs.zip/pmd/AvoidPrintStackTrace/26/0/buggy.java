public class foo {
    public static Df df(String dir) {
        String os = System.getProperty("os.name");
        if (os.startsWith("Windows")) {
            Df df = new Df();
            df.available = Long.MAX_VALUE / 1024;
            return df;
        }

        Process process;
        try {
            process = Runtime.getRuntime().exec("df " + dir);
            InputStream inputStream = process.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            // Filesystem      1K-blocks       Used Available Use% Mounted on
            // /dev/sdc       5814186096 5814169712         0 100% /home/spy-sd/sdc
            String titleLine = reader.readLine();
            String dataLine = reader.readLine();
            if (titleLine == null || dataLine == null) {
                return null;
            }
            String[] values = dataLine.split("\\s+");
            if (values.length != 6) {
                return null;
            }

            Df df = new Df();
            df.fileSystem = values[0];
            df.blocks = Long.parseLong(values[1]);
            df.used = Long.parseLong(values[2]);
            df.available = Long.parseLong(values[3]);
            df.useRate = Integer.parseInt(values[4].replace("%", ""));
            df.mountedOn = values[5];
            return df;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}