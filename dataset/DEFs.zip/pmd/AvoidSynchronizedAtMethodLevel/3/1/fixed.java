public class foo {
	private void dialogClosed() {
		dialogProvider = null;
	}
}