public class foo {
    protected synchronized void saveLastTriggerAndEmitExecution(SchedulerExecutionWithTrigger executionWithTrigger) {
        Trigger trigger = Trigger.of(
            executionWithTrigger.getTriggerContext(),
            executionWithTrigger.getExecution()
        );

        this.triggerState.save(trigger);
        this.executionQueue.emit(executionWithTrigger.getExecution());
    }
}