public class foo {
  @Override
  public ResultSet getImportedKeys(String arg0, String arg1, String arg2) throws SQLException {
    List<String> columnNameList = new ArrayList<String>();
    List<String> columnTypeList = new ArrayList<String>();
    Map<String, Integer> columnNameIndex = new HashMap<String, Integer>();
    Statement stmt = connection.createStatement();
    try {
      Field[] fields = new Field[14];
      fields[0] = new Field("", "PKTABLE_CAT", "TEXT");
      fields[1] = new Field("", "PKTABLE_SCHEM", "INT32");
      fields[2] = new Field("", "PKTABLE_NAME", "TEXT");
      fields[3] = new Field("", "PKCOLUMN_NAME", "TEXT");
      fields[4] = new Field("", "FKTABLE_CAT", "TEXT");
      fields[5] = new Field("", "FKTABLE_SCHEM", "TEXT");
      fields[6] = new Field("", "FKTABLE_NAME", "TEXT");
      fields[7] = new Field("", "FKCOLUMN_NAME", "TEXT");
      fields[8] = new Field("", "KEY_SEQ", "INT32");
      fields[9] = new Field("", "UPDATE_RULE", "INT32");
      fields[10] = new Field("", "DELETE_RULE", "INT32");
      fields[11] = new Field("", "FK_NAME", "TEXT");
      fields[12] = new Field("", "PK_NAME", "TEXT");
      fields[13] = new Field("", "DEFERRABILITY", "INT32");
      for (int i = 0; i < fields.length; i++) {
        columnNameList.add(fields[i].getName());
        columnTypeList.add(fields[i].getSqlType());
        columnNameIndex.put(fields[i].getName(), i);
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      close(null, stmt);
    }
    return new IoTDBJDBCResultSet(
        stmt,
        columnNameList,
        columnTypeList,
        columnNameIndex,
        false,
        client,
        null,
        -1,
        sessionId,
        null,
        null,
        (long) 60 * 1000,
        false);
  }
}