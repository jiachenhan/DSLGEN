public class foo {
    public Set<String> getSyncStateSet() {
        final Lock readLock = readWriteLock.readLock();
        try {
            readLock.lock();
            HashSet<String> set = new HashSet<>(this.syncStateSet.size());
            set.addAll(this.syncStateSet);
            return set;
        } finally {
            readLock.unlock();
        }
    }
}