public class foo {
    private void checkAllTaskFinal()
    {
        if (!stateMachine.getState().isDone()) {
            return;
        }
        synchronized (this) {
            if (tasksWithFinalInfo.size() == allTasks.size()) {
                List<TaskInfo> finalTaskInfos = tasks.values().stream()
                        .map(RemoteTask::getTaskInfo)
                        .collect(toImmutableList());
                stateMachine.setAllTasksFinal(finalTaskInfos);
            }
        }
    }
}