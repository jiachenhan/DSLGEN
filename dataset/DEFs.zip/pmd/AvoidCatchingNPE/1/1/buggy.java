public class foo {
  public void testWeak_null() {
    Interner<String> pool = Interners.newWeakInterner();
    try {
      pool.intern(null);
      fail();
    } catch (NullPointerException ok) {
    }
  }
}