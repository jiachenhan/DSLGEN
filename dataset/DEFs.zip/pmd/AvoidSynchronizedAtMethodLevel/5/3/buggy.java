public class foo {
  /** Returns whether a key exists in Android Keystore. */
  synchronized boolean hasKey(String keyUri) throws GeneralSecurityException {
    String keyId = Validators.validateKmsKeyUriAndRemovePrefix(PREFIX, keyUri);
    try {
      return getAndroidKeyStore().containsAlias(keyId);
    } catch (NullPointerException ex1) {
      Log.w(TAG, "Keystore is temporarily unavailable, wait, reinitialize Keystore and try again.");
      sleepRandomAmount();
      return getAndroidKeyStore().containsAlias(keyId);
    }
  }
}