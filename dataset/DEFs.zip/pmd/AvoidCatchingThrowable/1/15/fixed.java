public class foo {
    protected void deleteTestFolder() {
        try {
            testFolder.delete(true);
        } catch (Exception t) {
        }
        testFolder = null;
    }
}