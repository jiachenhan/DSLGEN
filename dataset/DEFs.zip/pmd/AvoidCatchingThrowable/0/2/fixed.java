public class foo {
  public static synchronized void launchPipeTaskAgent() {
    try (final ConfigNodeClient configNodeClient =
        ConfigNodeClientManager.getInstance().borrowClient(ConfigNodeInfo.CONFIG_REGION_ID)) {
      final TGetAllPipeInfoResp getAllPipeInfoResp = configNodeClient.getAllPipeInfo();
      if (getAllPipeInfoResp.getStatus().getCode()
          == TSStatusCode.EXECUTE_STATEMENT_ERROR.getStatusCode()) {
        throw new StartupException("Failed to get pipe task meta from config node.");
      }

      PipeAgent.task()
          .handlePipeMetaChanges(
              getAllPipeInfoResp.getAllPipeInfo().stream()
                  .map(
                      byteBuffer -> {
                        final PipeMeta pipeMeta = PipeMeta.deserialize(byteBuffer);
                        LOGGER.info(
                            "Pulled pipe meta from config node: {}, recovering ...", pipeMeta);
                        return pipeMeta;
                      })
                  .collect(Collectors.toList()));
    } catch (Exception e) {
      LOGGER.info(
          "Failed to get pipe task meta from config node. Ignore the exception, "
              + "because config node may not be ready yet, and meta will be pushed by config node later.",
          e);
    }
  }
}