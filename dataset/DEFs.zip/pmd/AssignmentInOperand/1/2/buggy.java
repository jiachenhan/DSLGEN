public class foo {
    public static void createTable(
            final FilesFacade ff,
            int mkDirMode,
            final CharSequence root,
            final CharSequence tableDir,
            final CharSequence tableName,
            TableStructure structure,
            int tableId,
            SecurityContext securityContext
    ) {
        try (Path path = new Path()) {
            switch (TableUtils.exists(ff, path, root, tableDir)) {
                case TableUtils.TABLE_EXISTS:
                    int errno;
                    if ((errno = ff.rmdir(path)) != 0) {
                        LOG.error().$("could not overwrite table [tableName='").utf8(tableName).$("',path='").utf8(path).$(", errno=").$(errno).I$();
                        throw CairoException.critical(errno).put("could not overwrite [tableName=").put(tableName).put("]");
                    }
                case TableUtils.TABLE_DOES_NOT_EXIST:
                    securityContext.authorizeTableCreate();
                    try (MemoryMARW memory = Vm.getMARWInstance()) {
                        TableUtils.createTable(
                                ff,
                                root,
                                mkDirMode,
                                memory,
                                path,
                                tableDir,
                                structure,
                                ColumnType.VERSION,
                                tableId
                        );
                    }
                    break;
                default:
                    throw TextException.$("name is reserved [tableName=").put(tableName).put(']');
            }
        }
    }
}