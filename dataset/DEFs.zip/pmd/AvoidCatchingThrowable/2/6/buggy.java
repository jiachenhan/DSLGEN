public class foo {
    @Override
    public boolean process(Exchange exchange, AsyncCallback callback) {
        ObjectHelper.notNull(dataFormat, "dataFormat");

        InputStream stream = null;
        Object result = null;
        try {
            final Message in = exchange.getIn();
            final Message out;
            if (allowNullBody && in.getBody() == null) {
                // The body is null, and it is an allowed value so let's skip the unmarshalling
                out = exchange.getOut();
            } else {
                stream = in.getMandatoryBody(InputStream.class);

                // lets set up the out message before we invoke the dataFormat so that it can mutate it if necessary
                out = exchange.getOut();
                out.copyFrom(in);

                result = dataFormat.unmarshal(exchange, stream);
            }
            if (result instanceof Exchange) {
                if (result != exchange) {
                    // it's not allowed to return another exchange other than the one provided to dataFormat
                    throw new RuntimeCamelException(
                            "The returned exchange " + result + " is not the same as " + exchange
                                                    + " provided to the DataFormat");
                }
            } else if (result instanceof Message) {
                // the dataformat has probably set headers, attachments, etc. so let's use it as the outbound payload
                exchange.setOut((Message) result);
            } else {
                out.setBody(result);
            }
        } catch (Throwable e) {
            // remove OUT message, as an exception occurred
            exchange.setOut(null);
            exchange.setException(e);
        } finally {
            // The Iterator will close the stream itself
            if (!(result instanceof Iterator)) {
                IOHelper.close(stream, "input stream");
            }
        }
        callback.done(true);
        return true;
    }
}