public class foo {
    /**
     * generate config and session variable doc from given templates
     *
     * @param args args[0]: config doc template path
     * args[1]: config doc template path CN
     * args[2]: config doc output path
     * args[3]: config doc output path CN
     * args[4]: session variable doc template path
     * args[5]: session variable doc template path CN
     * args[6]: session variable doc output path
     * args[7]: session variable doc output path CN
     */
    public static void main(String[] args) {
        String configDocTemplatePath = args[0];
        String configDocTemplatePathCN = args[1];
        String configDocOutputPath = args[2];
        String configDocOutputPathCN = args[3];
        String sessionVariableDocTemplatePath = args[4];
        String sessionVariableDocTemplatePathCN = args[5];
        String sessionVariableDocOutputPath = args[6];
        String sessionVariableDocOutputPathCN = args[7];
        DocGenerator docGenerator = new DocGenerator(
                configDocTemplatePath, configDocTemplatePathCN,
                configDocOutputPath, configDocOutputPathCN,
                sessionVariableDocTemplatePath, sessionVariableDocTemplatePathCN,
                sessionVariableDocOutputPath, sessionVariableDocOutputPathCN);
        try {
            docGenerator.generate();
            System.out.println("Done!");
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }
}