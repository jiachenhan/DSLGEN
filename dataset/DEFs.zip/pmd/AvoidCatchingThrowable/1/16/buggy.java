public class foo {
    @Test
    public void testInvokingServiceFromCXFClient() throws Exception {
        JaxWsProxyFactoryBean proxyFactory = new JaxWsProxyFactoryBean();
        ClientFactoryBean clientBean = proxyFactory.getClientFactoryBean();
        clientBean.setAddress(ROUTER_ADDRESS);
        clientBean.setServiceClass(Greeter.class);

        Greeter client = (Greeter) proxyFactory.create();

        try {
            client.pingMe();
            fail("Expect to get an exception here");
        } catch (PingMeFault expected) {
            assertEquals(MESSAGE, expected.getMessage());
        } catch (Throwable t) {
            LOG.warn("The CXF client did not manage to map the client exception: {}", t.getMessage(), t);
            fail("The CXF client did not manage to map the client exception "
                 + t.getClass().getName() + " to a " + PingMeFault.class.getName()
                 + ": " + t.getMessage());
        }

    }
}