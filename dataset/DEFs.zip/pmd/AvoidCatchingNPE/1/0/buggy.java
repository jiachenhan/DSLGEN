public class foo {
  public void testStrong_null() {
    Interner<String> pool = Interners.newStrongInterner();
    try {
      pool.intern(null);
      fail();
    } catch (NullPointerException ok) {
    }
  }
}