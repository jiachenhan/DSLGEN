public class foo {
    @Override
    public void validatePerColumnIndexComponents(IndexDescriptor indexDescriptor, IndexContext indexContext, boolean checksum)
    {
        for (IndexComponent indexComponent : perColumnIndexComponents(indexContext))
        {
            if (isNotBuildCompletionMarker(indexComponent))
            {
                try (IndexInput input = indexDescriptor.openPerIndexInput(indexComponent, indexContext))
                {
                    if (checksum)
                        SAICodecUtils.validateChecksum(input);
                    else
                        SAICodecUtils.validate(input);
                }
                catch (Exception e)
                {
                    logger.warn(indexDescriptor.logMessage("{} failed for index component {} on SSTable {}"),
                                                           checksum ? "Checksum validation" : "Validation",
                                                           indexComponent,
                                                           indexDescriptor.sstableDescriptor);
                    rethrowIOException(e);
                }
            }
        }
    }
}