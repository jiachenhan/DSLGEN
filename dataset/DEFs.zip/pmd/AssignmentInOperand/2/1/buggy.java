public class foo {
	/**
	 * Reads the {@link DebugInfoEntry} records for this compilation unit from the .debug_info
	 * section.
	 * <p>
	 * @param entries List of DIE records that is written to by this method.  This list should
	 * be empty if the caller only wants this CU's records (ie. normal mode), or the list
	 * can be used to accumulate all DIE records (preload all DIE mode).
	 * @param monitor {@link TaskMonitor} to watch for cancelation
	 * @throws IOException if error reading data
	 * @throws DWARFException if error in DWARF structure
	 * @throws CancelledException if user cancels.
	 */
	public void readDIEs(List<DebugInfoEntry> entries, TaskMonitor monitor)
			throws IOException, DWARFException, CancelledException {

		BinaryReader br = dwarfProgram.getDebugInfo();
		br.setPointerIndex(getFirstDIEOffset());

		Deque<DebugInfoEntry> parentStack = new ArrayDeque<>();

		DebugInfoEntry parent = null;
		DebugInfoEntry die;
		DebugInfoEntry unexpectedTerminator = null;
		while ((br.getPointerIndex() < getEndOffset()) &&
			(die = DebugInfoEntry.read(br, this, dwarfProgram.getAttributeFactory())) != null) {

			monitor.checkCancelled();

			if (die.isTerminator()) {
				if (parent == null && parentStack.isEmpty()) {
					unexpectedTerminator = die;
					continue;
				}
				parent = !parentStack.isEmpty() ? parentStack.pop() : null;
				continue;
			}

			if (unexpectedTerminator != null) {
				throw new DWARFException("Unexpected terminator entry at " +
					Long.toHexString(unexpectedTerminator.getOffset()));
			}
			entries.add(die);

			if (parent != null) {
				parent.addChild(die);
				die.setParent(parent);
			}
			else {
				if (die.getOffset() != getFirstDIEOffset()) {
					throw new DWARFException(
						"Unexpected root level DIE at " + Long.toHexString(die.getOffset()));
				}
			}

			if (die.getAbbreviation().hasChildren()) {
				if (parent != null) {
					parentStack.push(parent);
				}
				parent = die;
			}
		}
	}
}