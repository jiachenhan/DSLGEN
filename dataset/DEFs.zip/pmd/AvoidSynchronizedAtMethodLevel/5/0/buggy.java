public class foo {
    public synchronized Set<String> getSyncStateSet() {
        HashSet<String> set = new HashSet<>(this.syncStateSet.size());
        set.addAll(this.syncStateSet);
        return set;
    }
}