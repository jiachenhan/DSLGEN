public class foo {
        synchronized void kill() {
            updateKillState(KILL);
        }
}