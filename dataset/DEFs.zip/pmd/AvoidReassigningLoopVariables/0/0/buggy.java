public class foo {
  @SuppressWarnings("squid:S107")
  void autoCreateMissingMeasurements(
      ClusterSchemaTree schemaTree,
      List<PartialPath> devicePathList,
      List<Integer> indexOfTargetDevices,
      List<List<Integer>> indexOfTargetMeasurementsList,
      List<String[]> measurementsList,
      List<TSDataType[]> tsDataTypesList,
      List<TSEncoding[]> encodingsList,
      List<CompressionType[]> compressionTypesList,
      List<Boolean> isAlignedList,
      MPPQueryContext context) {
    // Check whether there is template should be activated

    Map<PartialPath, Pair<Template, PartialPath>> devicesNeedActivateTemplate = new HashMap<>();
    Map<PartialPath, Pair<Boolean, MeasurementGroup>> devicesNeedAutoCreateTimeSeries =
        new HashMap<>();
    int deviceIndex;
    PartialPath devicePath;
    List<Integer> indexOfTargetMeasurements;
    Pair<Template, PartialPath> templateInfo;
    Template template;
    List<Integer> indexOfMeasurementsNotInTemplate;
    Map<String, TemplateExtendInfo> templateExtendInfoMap = new HashMap<>();
    for (int i = 0, size = indexOfTargetDevices.size(); i < size; i++) {
      deviceIndex = indexOfTargetDevices.get(i);
      devicePath = devicePathList.get(deviceIndex);
      indexOfTargetMeasurements = indexOfTargetMeasurementsList.get(i);

      templateInfo = devicesNeedActivateTemplate.get(devicePath);
      if (templateInfo == null) {
        templateInfo = templateManager.checkTemplateSetInfo(devicePath);
      }

      if (templateInfo == null) {
        // There are measurements need to be created as normal timeseries
        int finalDeviceIndex = deviceIndex;
        List<Integer> finalIndexOfMeasurementsNotInTemplate = indexOfTargetMeasurements;
        devicesNeedAutoCreateTimeSeries.compute(
            devicePath,
            (k, v) -> {
              if (v == null) {
                v = new Pair<>(isAlignedList.get(finalDeviceIndex), new MeasurementGroup());
              }
              MeasurementGroup measurementGroup = v.right;
              String[] measurements = measurementsList.get(finalDeviceIndex);
              TSDataType[] tsDataTypes = tsDataTypesList.get(finalDeviceIndex);
              TSEncoding[] encodings =
                  encodingsList == null ? null : encodingsList.get(finalDeviceIndex);
              CompressionType[] compressionTypes =
                  compressionTypesList == null ? null : compressionTypesList.get(finalDeviceIndex);
              for (int measurementIndex : finalIndexOfMeasurementsNotInTemplate) {
                if (tsDataTypes[measurementIndex] == null) {
                  continue;
                }
                measurementGroup.addMeasurement(
                    measurements[measurementIndex],
                    tsDataTypes[measurementIndex],
                    encodings == null
                        ? getDefaultEncoding(tsDataTypes[measurementIndex])
                        : encodings[measurementIndex],
                    compressionTypes == null
                        ? TSFileDescriptor.getInstance().getConfig().getCompressor()
                        : compressionTypes[measurementIndex]);
              }
              return v;
            });
      } else {
        template = templateInfo.left;
        indexOfMeasurementsNotInTemplate =
            checkMeasurementsInSchemaTemplate(
                indexOfTargetMeasurements, measurementsList.get(deviceIndex), template);
        if (schemaTree.getMatchedDevices(devicePath).isEmpty()) {
          // Not activated yet
          devicesNeedActivateTemplate.putIfAbsent(devicePath, templateInfo);
        }

        if (!indexOfMeasurementsNotInTemplate.isEmpty()) {
          List<Integer> finalIndexOfMeasurementsNotInTemplate1 = indexOfMeasurementsNotInTemplate;
          int finalDeviceIndex1 = deviceIndex;
          templateExtendInfoMap.compute(
              template.getName(),
              (k, v) -> {
                TemplateExtendInfo templateExtendInfo;
                if (v == null) {
                  templateExtendInfo = new TemplateExtendInfo(k);
                } else {
                  templateExtendInfo = v;
                }

                String measurement;
                TSDataType dataType;
                TSEncoding encoding;
                CompressionType compressionType;
                for (int index : finalIndexOfMeasurementsNotInTemplate1) {
                  measurement = measurementsList.get(finalDeviceIndex1)[index];
                  dataType = tsDataTypesList.get(finalDeviceIndex1)[index];
                  if (encodingsList != null && encodingsList.get(finalDeviceIndex1) != null) {
                    encoding = encodingsList.get(finalDeviceIndex1)[index];
                  } else {
                    encoding = getDefaultEncoding(dataType);
                  }
                  if (compressionTypesList != null
                      && compressionTypesList.get(finalDeviceIndex1) != null) {
                    compressionType = compressionTypesList.get(finalDeviceIndex1)[index];
                  } else {
                    compressionType = TSFileDescriptor.getInstance().getConfig().getCompressor();
                  }
                  templateExtendInfo.addMeasurement(
                      measurement, dataType, encoding, compressionType);
                }
                return templateExtendInfo;
              });
        }
      }
    }

    if (!templateExtendInfoMap.isEmpty()) {
      for (TemplateExtendInfo templateExtendInfo : templateExtendInfoMap.values()) {
        templateExtendInfo = templateExtendInfo.deduplicate();
        internalExtendTemplate(
            templateExtendInfo.getTemplateName(),
            templateExtendInfo.getMeasurements(),
            templateExtendInfo.getDataTypes(),
            templateExtendInfo.getEncodings(),
            templateExtendInfo.getCompressors(),
            context);
      }
      for (Pair<Template, PartialPath> value : devicesNeedActivateTemplate.values()) {
        value.left = templateManager.getTemplate(value.left.getId());
      }
    }

    if (!devicesNeedActivateTemplate.isEmpty()) {
      internalActivateTemplate(devicesNeedActivateTemplate, context);
      for (Map.Entry<PartialPath, Pair<Template, PartialPath>> entry :
          devicesNeedActivateTemplate.entrySet()) {
        devicePath = entry.getKey();
        // Take the latest template
        template = templateManager.getTemplate(entry.getValue().left.getId());
        schemaTree.appendTemplateDevice(
            devicePath, template.isDirectAligned(), template.getId(), template);
      }
    }

    if (!devicesNeedAutoCreateTimeSeries.isEmpty()) {
      internalCreateTimeSeries(schemaTree, devicesNeedAutoCreateTimeSeries, context);
    }
  }
}