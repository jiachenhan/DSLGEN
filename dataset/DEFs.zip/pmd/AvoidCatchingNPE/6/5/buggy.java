public class foo {
  public void testCopyOf_map_nulls() {
    Map<Class<? extends Number>, Number> nullKey = Collections.singletonMap(null, (Number) 1.0);
    try {
      ImmutableClassToInstanceMap.copyOf(nullKey);
      fail();
    } catch (NullPointerException expected) {
    }

    Map<? extends Class<? extends Number>, Number> nullValue =
        Collections.singletonMap(Number.class, null);
    try {
      ImmutableClassToInstanceMap.copyOf(nullValue);
      fail();
    } catch (NullPointerException expected) {
    }
  }
}