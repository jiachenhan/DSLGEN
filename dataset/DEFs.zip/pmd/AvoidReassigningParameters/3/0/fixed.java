public class foo {
    private Expression processDecimalV3TypeCoercion(ComparisonPredicate comparisonPredicate,
            Expression left, Expression right) {
        if (left instanceof Cast && right instanceof DecimalV3Literal) {
            Cast cast = (Cast) left;
            left = cast.child();
            DecimalV3Literal literal = (DecimalV3Literal) right;
            if (left.getDataType().isDecimalV3Type()) {
                if (((DecimalV3Type) left.getDataType())
                        .getScale() < ((DecimalV3Type) literal.getDataType()).getScale()) {
                    int toScale = ((DecimalV3Type) left.getDataType()).getScale();
                    if (comparisonPredicate instanceof EqualTo) {
                        try {
                            return comparisonPredicate.withChildren(left,
                                    new DecimalV3Literal((DecimalV3Type) left.getDataType(),
                                            literal.getValue().setScale(toScale)));
                        } catch (ArithmeticException e) {
                            if (left.nullable()) {
                                // TODO: the ideal way is to return an If expr like:
                                // return new If(new IsNull(left), new NullLiteral(BooleanType.INSTANCE),
                                // BooleanLiteral.of(false));
                                // but current fold constant rule can't handle such complex expr with null literal
                                // before supporting complex conjuncts with null literal folding rules,
                                // we use a trick way like this:
                                return new And(new IsNull(left),
                                        new NullLiteral(BooleanType.INSTANCE));
                            } else {
                                return BooleanLiteral.of(false);
                            }
                        }
                    } else if (comparisonPredicate instanceof NullSafeEqual) {
                        try {
                            return comparisonPredicate.withChildren(left,
                                    new DecimalV3Literal((DecimalV3Type) left.getDataType(),
                                            literal.getValue().setScale(toScale)));
                        } catch (ArithmeticException e) {
                            return BooleanLiteral.of(false);
                        }
                    } else if (comparisonPredicate instanceof GreaterThan
                            || comparisonPredicate instanceof LessThanEqual) {
                        return comparisonPredicate.withChildren(left, literal.roundFloor(toScale));
                    } else if (comparisonPredicate instanceof LessThan
                            || comparisonPredicate instanceof GreaterThanEqual) {
                        return comparisonPredicate.withChildren(left,
                                literal.roundCeiling(toScale));
                    }
                }
            } else if (left.getDataType().isIntegerLikeType()) {
                return processIntegerDecimalLiteralComparison(comparisonPredicate, left,
                        literal.getValue());
            }
        }

        return comparisonPredicate;
    }
}