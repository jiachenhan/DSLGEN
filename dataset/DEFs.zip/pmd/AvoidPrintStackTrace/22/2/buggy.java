public class foo {
    private static String createJwt(String key, String secret) {
        Algorithm alg;
        try {
            alg = Algorithm.HMAC256(secret.getBytes("utf-8"));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        Map<String, Object> payload = new HashMap<>();
        payload.put("api_key", key);
        payload.put("exp", System.currentTimeMillis() + 30 * 60 * 1000);
        payload.put("timestamp", Calendar.getInstance().getTimeInMillis());
        Map<String, Object> headerClaims = new HashMap<>();
        headerClaims.put("alg", "HS256");
        headerClaims.put("sign_type", "SIGN");
        String token = JWT.create().withPayload(payload).withHeader(headerClaims).sign(alg);
        return token;
    }
}