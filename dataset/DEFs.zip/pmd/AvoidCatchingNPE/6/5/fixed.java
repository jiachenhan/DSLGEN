public class foo {
  public void testCopyOf_map_nulls() {
    Map<Class<? extends Number>, Number> nullKey = Collections.singletonMap(null, (Number) 1.0);
    assertThrows(NullPointerException.class, () -> ImmutableClassToInstanceMap.copyOf(nullKey));

    Map<? extends Class<? extends Number>, Number> nullValue =
        Collections.singletonMap(Number.class, null);
    assertThrows(NullPointerException.class, () -> ImmutableClassToInstanceMap.copyOf(nullValue));
  }
}