public class foo {
    /**
     * If the message body contains a {@link StreamCache} instance, reset the cache to enable reading from it again.
     *
     * @param message the message for which to reset the body
     */
    public static void resetStreamCache(Message message) {
        if (message == null) {
            return;
        }
        Object body = null;
        try {
            body = message.getBody();
        } catch (Throwable e) {
            // ignore
        }
        if (body instanceof StreamCache) {
            ((StreamCache) body).reset();
        }
    }
}