public class foo {
  public void testNewReader() throws IOException {
    File asciiFile = getTestFile("ascii.txt");
    assertThrows(NullPointerException.class, () -> Files.newReader(asciiFile, null));

    assertThrows(NullPointerException.class, () -> Files.newReader(null, Charsets.UTF_8));

    BufferedReader r = Files.newReader(asciiFile, Charsets.US_ASCII);
    try {
      assertEquals(ASCII, r.readLine());
    } finally {
      r.close();
    }
  }
}