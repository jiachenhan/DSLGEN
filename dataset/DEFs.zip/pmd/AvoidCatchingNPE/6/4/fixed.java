public class foo {
  public void testTransform_present_functionReturnsNull() {
    assertThrows(NullPointerException.class, () -> Optional.of("a").transform(input -> null));
  }
}