public class foo {
        private S loadExtension(ClassLoader loader, Class<?>[] argTypes,
                                Object[] args) {
            try {
                loadAllExtensionClass(loader);
                ExtensionDefinition<S> defaultExtensionDefinition = getDefaultExtensionDefinition();
                return getExtensionInstance(defaultExtensionDefinition, loader, argTypes, args);
            } catch (EnhancedServiceNotFoundException e) {
                throw e;
            } catch (Throwable e) {
                throw new EnhancedServiceNotFoundException(
                    "not found service provider for : " + type.getName()
                        + " caused by " + ExceptionUtils.getFullStackTrace(e));
            }
        }
}