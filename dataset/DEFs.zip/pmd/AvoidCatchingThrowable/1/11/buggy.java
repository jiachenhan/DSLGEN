public class foo {
    private void deleteTestGroup() {
        if (testGroup != null) {
            try {
                testGroup.delete();
            } catch (Throwable t) {
            }
            testGroup = null;
        }
    }
}