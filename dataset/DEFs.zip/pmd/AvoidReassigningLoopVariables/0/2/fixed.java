public class foo {
    private void analyzePeriodically() {
        try {
            AnalysisManager analysisManager = Env.getCurrentEnv().getAnalysisManager();
            List<AnalysisInfo> jobInfos = analysisManager.findPeriodicJobs();
            for (AnalysisInfo jobInfo : jobInfos) {
                createSystemAnalysisJob(jobInfo);
            }
        } catch (Exception e) {
            LOG.warn("Failed to periodically analyze the statistics." + e);
        }
    }
}