public class foo {
  public void testGetCasualChainNull() {
    assertThrows(NullPointerException.class, () -> getCausalChain(null));
  }
}