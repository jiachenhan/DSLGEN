public class foo {
  @SuppressWarnings("squid:S2142")
  @Override
  public void run() {
    while (!Thread.currentThread().isInterrupted()) {
      AbstractCompactionTask task;
      try {
        task = compactionTaskQueue.take();
      } catch (InterruptedException e) {
        log.warn("CompactionThread-{} terminates because interruption", threadId);
        return;
      }
      try {
        if (task != null && task.checkValidAndSetMerging()) {
          CompactionTaskSummary summary = task.getSummary();
          CompactionTaskFuture future = new CompactionTaskFuture(summary);
          CompactionTaskManager.getInstance().recordTask(task, future);
          task.start();
        }
      } catch (Exception e) {
        log.error("CompactionWorker.run(), Exception.", e);
      }
    }
  }
}