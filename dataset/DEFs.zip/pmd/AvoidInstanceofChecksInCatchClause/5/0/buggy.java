public class foo {
	@Test
	@Disabled
	public void downloadFileFromUrlTest4() {
		File file = null;
		try {
			file = HttpDownloader.downloadFile("http://groovy-lang.org/changelogs/changelog-3.0.5.html", FileUtil.file("d:/download/temp"), 1);

			Assertions.assertNotNull(file);
			Assertions.assertTrue(file.exists());
			Assertions.assertTrue(file.isFile());
			Assertions.assertTrue(file.length() > 0);
			Assertions.assertTrue(file.getName().length() > 0);
		} catch (final Exception e) {
			Assertions.assertTrue(e instanceof IORuntimeException);
		} finally {
			FileUtil.del(file);
		}
	}
}