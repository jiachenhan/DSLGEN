public class foo {
  public void testCopyOf_multisetContainingNull() {
    Multiset<String> c = HashMultiset.create(asList("a", null, "b"));
    try {
      ImmutableSortedMultiset.copyOf(c);
      fail();
    } catch (NullPointerException expected) {
    }
  }
}