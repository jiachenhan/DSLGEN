public class foo {
  @Override
  public void close()
      throws IOException {
    Preconditions.checkState(_stopped, "Must stop the metadata manager before closing it");
    _logger.info("Closing the metadata manager");
    synchronized (_numPendingOperations) {
      int numPendingOperations;
      while ((numPendingOperations = _numPendingOperations.get()) != 0) {
        _logger.info("Waiting for {} pending operations to finish", numPendingOperations);
        try {
          _numPendingOperations.wait();
        } catch (InterruptedException e) {
          throw new RuntimeException(
              String.format("Interrupted while waiting for %d pending operations to finish", numPendingOperations), e);
        }
      }
    }
    doClose();
    _logger.info("Closed the metadata manager");
  }
}