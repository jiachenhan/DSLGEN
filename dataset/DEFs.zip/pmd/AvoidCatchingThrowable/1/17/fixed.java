public class foo {
    private void emitEvent(Listener.Type type, K key, V value) {
        for (Listener<K, V> listener : listeners) {
            try {
                listener.timeoutMapEvent(type, key, value);
            } catch (Exception t) {
                // Ignore
            }
        }
    }
}