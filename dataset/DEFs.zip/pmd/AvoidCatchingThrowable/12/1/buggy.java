public class foo {
    @Override
    public boolean validatePerSSTableIndexComponents(IndexDescriptor indexDescriptor, boolean checksum)
    {
        for (IndexComponent indexComponent : perSSTableIndexComponents())
        {
            if (isNotBuildCompletionMarker(indexComponent))
            {
                try (IndexInput input = indexDescriptor.openPerSSTableInput(indexComponent))
                {
                    if (checksum)
                        SAICodecUtils.validateChecksum(input);
                    else
                        SAICodecUtils.validate(input);
                }
                catch (Throwable e)
                {
                    logger.error(indexDescriptor.logMessage("{} failed for index component {} on SSTable {}. Error: {}"),
                                 checksum ? "Checksum validation" : "Validation",
                                 indexComponent,
                                 indexDescriptor.sstableDescriptor,
                                 e);
                    return false;
                }
            }
        }
        return true;
    }
}