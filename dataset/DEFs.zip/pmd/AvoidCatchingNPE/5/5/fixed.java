public class foo {
  public void testBuilderAddCopiesHandlesNullsCorrectly() {
    ImmutableSortedMultiset.Builder<String> builder = ImmutableSortedMultiset.naturalOrder();
    assertThrows(NullPointerException.class, () -> builder.addCopies(null, 2));
  }
}