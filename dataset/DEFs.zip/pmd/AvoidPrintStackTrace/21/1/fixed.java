public class foo {
    @Test
    public void testModifyColumnsWithAMV2() {
        try {
            checkModifyColumnsWithMaterializedViews(starRocksAssert,
                    "create materialized view mv1 distributed by random refresh deferred manual " +
                            "as select timestamp, count(error_code) as cnt from sc_dup3 " +
                            "where op_id * 2 > 10 group by timestamp",
                    "alter table sc_dup3 drop column error_code",
                    false);
            MaterializedView mv = (MaterializedView) starRocksAssert.getTable("test", "mv1");
            Assert.assertFalse(mv.isActive());
            Assert.assertTrue(mv.getInactiveReason().contains("base table schema changed for columns: error_code"));
        } catch (Exception e) {
            Assert.fail();
        } finally {
            try {
                starRocksAssert.dropMaterializedView("mv1");
            } catch (Exception e) {
                // ignore
            }
        }
    }
}