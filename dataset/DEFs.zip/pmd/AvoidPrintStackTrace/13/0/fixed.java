public class foo {
    @Override
    byte[] finalize(Object value) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream outputStream = new DataOutputStream(bos);
            ((BitmapValue) value).serialize(outputStream);
            return bos.toByteArray();
        } catch (IOException ioException) {
            LOG.warn("", ioException);
            throw new RuntimeException(ioException);
        }
    }
}