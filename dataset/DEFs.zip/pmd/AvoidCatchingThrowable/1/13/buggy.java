public class foo {
    protected void deleteTestFile() {
        try {
            testFile.delete();
        } catch (Throwable t) {
        }
        testFile = null;
    }
}