public class foo {
	private synchronized void dialogClosed() {
		dialogProvider = null;
	}
}