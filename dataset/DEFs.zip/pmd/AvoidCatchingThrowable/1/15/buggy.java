public class foo {
    protected void deleteTestFolder() {
        try {
            testFolder.delete(true);
        } catch (Throwable t) {
        }
        testFolder = null;
    }
}