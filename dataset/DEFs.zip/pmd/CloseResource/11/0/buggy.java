public class foo {
    @Test
    public void testAliasExpansion() throws Exception {

        MockEndpoint mock = context.getEndpoint("mock:reverse", MockEndpoint.class);
        assertNotNull(mock);
        mock.expectedMessageCount(0);

        InputStream is = this.getClass().getClassLoader().getResourceAsStream("data-dos.yaml");

        ProducerTemplate template = context.createProducerTemplate();

        Exception ex = assertThrows(CamelExecutionException.class,
                () -> template.requestBody("direct:back", is, String.class),
                "Failure expected on an alias expansion attack");

        Throwable cause = ex.getCause();
        assertEquals("Number of aliases for non-scalar nodes exceeds the specified max=50", cause.getMessage());

        mock.assertIsSatisfied();
    }
}