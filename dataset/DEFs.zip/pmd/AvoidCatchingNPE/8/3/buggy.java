public class foo {
  public void testFromByteArray_withNullInputThrowsNullPointerException() {
    try {
      Stats.fromByteArray(null);
      fail("Expected NullPointerException");
    } catch (NullPointerException expected) {
    }
  }
}