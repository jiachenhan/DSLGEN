public class foo {
  public void testNull() {
    assertThrows(NullPointerException.class, () -> map.put(null, new Integer(1)));
    map.putInstance(Integer.class, null);
    assertNull(map.get(Integer.class));
    assertNull(map.getInstance(Integer.class));

    map.put(Long.class, null);
    assertNull(map.get(Long.class));
    assertNull(map.getInstance(Long.class));
  }
}