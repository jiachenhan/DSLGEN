public class foo {
  public void testToString_addWithNullName() {
    MoreObjects.ToStringHelper helper = MoreObjects.toStringHelper(new TestClass());
    try {
      helper.add(null, "Hello");
      fail("No exception was thrown.");
    } catch (NullPointerException expected) {
    }
  }
}