public class foo {
    private void downloadLibraryFiles(final DBRProgressMonitor monitor) throws InterruptedException {
        if (!acceptDriverLicenses()) {
            return;
        }

        boolean processUnsecure = false;
        List<DBPDriverDependencies.DependencyNode> nodes = getWizard().getDependencies().getLibraryList();
        for (int i = 0, filesSize = nodes.size(); i < filesSize; ) {
            final DBPDriverLibrary lib = nodes.get(i).library;
            if (!processUnsecure && !lib.isSecureDownload(monitor)) {
                boolean process = new UIConfirmation() {
                    @Override
                    protected Boolean runTask() {
                        MessageBox messageBox = new MessageBox(getShell(), SWT.ICON_WARNING | SWT.YES | SWT.NO);
                        messageBox.setText(UIConnectionMessages.dialog_driver_download_auto_page_driver_security_warning);
                        messageBox.setMessage(NLS.bind(UIConnectionMessages.dialog_driver_download_auto_page_driver_security_warning_msg,
                                lib.getDisplayName(), lib.getExternalURL(monitor)));
                        int response = messageBox.open();
                        return (response == SWT.YES);
                    }
                }.execute();
                if (process) {
                    processUnsecure = true;
                } else {
                    break;
                }
            }
            int result = IDialogConstants.OK_ID;
            try {
                lib.downloadLibraryFile(monitor, getWizard().isForceDownload(), NLS.bind(UIConnectionMessages.dialog_driver_download_auto_page_download_rate, (i + 1), filesSize));
            } catch (final IOException e) {
                if (lib.getType() == DBPDriverLibrary.FileType.license) {
                    result = IDialogConstants.OK_ID;
                } else {
                    result = new UITask<Integer>() {
                        @Override
                        protected Integer runTask() {
                            String message;
                            if (RuntimeUtils.isWindows() && GeneralUtils.hasCause(e, SSLHandshakeException.class)) {
                                if (DBWorkbench.getPlatform().getApplication()
                                    .hasProductFeature(DBConnectionConstants.PRODUCT_FEATURE_SIMPLE_TRUSTSTORE)) {
                                    message = UIConnectionMessages.dialog_driver_download_auto_page_download_failed_cert_msg;
                                } else {
                                    message = UIConnectionMessages.dialog_driver_download_auto_page_download_failed_cert_msg_advanced;
                                }
                            } else {
                                message = UIConnectionMessages.dialog_driver_download_auto_page_download_failed_msg;
                            }
                            DownloadErrorDialog dialog = new DownloadErrorDialog(null, lib.getDisplayName(), message, e);
                            return dialog.open();
                        }
                    }.execute();
                }
            }
            switch (result) {
                case IDialogConstants.CANCEL_ID:
                case IDialogConstants.ABORT_ID:
                    return;
                case IDialogConstants.RETRY_ID:
                    continue;
                case IDialogConstants.OK_ID:
                case IDialogConstants.IGNORE_ID:
                    i++;
                    break;
            }
        }

        ((DriverDescriptor)getWizard().getDriver()).setModified(true);
        //DataSourceProviderRegistry.getInstance().saveDrivers();
    }
}