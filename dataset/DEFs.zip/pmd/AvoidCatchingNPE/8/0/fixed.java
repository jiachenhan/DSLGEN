public class foo {
  public void testResolveType() {
    assertEquals(String.class, TypeToken.of(this.getClass()).resolveType(String.class).getType());
    assertEquals(
        String.class,
        TypeToken.of(StringIterable.class)
            .resolveType(Iterable.class.getTypeParameters()[0])
            .getType());
    assertEquals(
        String.class,
        TypeToken.of(StringIterable.class)
            .resolveType(Iterable.class.getTypeParameters()[0])
            .getType());
    assertThrows(NullPointerException.class, () -> TypeToken.of(this.getClass()).resolveType(null));
  }
}