public class foo {
  public void testCheckNotNull_simpleMessage_failure() {
    NullPointerException expected =
        assertThrows(NullPointerException.class, () -> checkNotNull(null, new Message()));
    verifySimpleMessage(expected);
  }
}