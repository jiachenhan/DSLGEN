public class foo {
  /** constructor with null array throws NPE */
  public void testConstructor2NPE() {
    double[] a = null;
    assertThrows(NullPointerException.class, () -> new AtomicDoubleArray(a));
  }
}