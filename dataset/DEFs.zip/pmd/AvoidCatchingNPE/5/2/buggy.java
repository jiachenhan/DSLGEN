public class foo {
  public void testGet_null() throws ExecutionException {
    for (LoadingCache<Object, Object> cache : caches()) {
      try {
        cache.get(null);
        fail("Expected NullPointerException");
      } catch (NullPointerException expected) {
      }
      checkEmpty(cache);
    }
  }
}