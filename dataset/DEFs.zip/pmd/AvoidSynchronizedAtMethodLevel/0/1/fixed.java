public class foo {
        void exit() {
            StopAction action;
            synchronized (this) {
                action = updateKillState(EXITING);
            }
            if (action != null) {
                getContext().getEnv().submitThreadLocal(new Thread[]{action.host}, action);
            }
        }
}