public class foo {
  @Override
  public Connection getConnection(String username, String password) {
    try {
      Properties newProp = new Properties();
      newProp.setProperty("user", username);
      newProp.setProperty(PWD_STR, password);
      return new IoTDBConnection(url, newProp);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }
}