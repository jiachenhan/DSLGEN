public class foo {
  public void testToString_addWithNullName() {
    MoreObjects.ToStringHelper helper = MoreObjects.toStringHelper(new TestClass());
    assertThrows(NullPointerException.class, () -> helper.add(null, "Hello"));
  }
}