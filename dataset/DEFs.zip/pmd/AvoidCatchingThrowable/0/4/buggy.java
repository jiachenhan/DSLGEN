public class foo {
    @Test
    public void testAdminCanSeeOtherPeoplesQueries() throws Exception {
        assertMemoryLeak(() -> {
            final String query = "select 1 t from long_sequence(1) where sleep(120000)";

            SOCountDownLatch started = new SOCountDownLatch(1);
            SOCountDownLatch stopped = new SOCountDownLatch(1);
            AtomicReference<Exception> error = new AtomicReference<>();

            new Thread(() -> {
                started.countDown();
                try {
                    try (SqlCompiler compiler = engine.getSqlCompiler()) {
                        TestUtils.assertSql(compiler, regularUserContext1, query, sink, "t\n1\n");
                        Assert.fail("Query should have been cancelled");
                    } catch (Exception e) {
                        if (!e.getMessage().contains("cancelled by user")) {
                            error.set(e);
                        }
                    }
                } finally {
                    stopped.countDown();
                }
            }, "query_thread").start();

            started.await();

            try {
                try (SqlCompiler compiler = engine.getSqlCompiler()) {
                    String activityQuery = "select query_id, query from query_activity() where query ='" + query + "'";

                    long queryId = -1;
                    try (final RecordCursorFactory factory = CairoEngine.select(compiler, activityQuery, adminUserContext1)) {
                        // admin can see admin's command
                        while (error.get() == null) {
                            try (RecordCursor cursor = factory.getCursor(adminUserContext1)) {
                                if (cursor.hasNext()) {
                                    queryId = cursor.getRecord().getLong(0);
                                    break;
                                }
                            }
                        }
                    }

                    ddl("cancel query " + queryId, adminUserContext1);
                }

                stopped.await();
                if (error.get() != null) {
                    throw error.get();
                }
            } catch (Throwable th) {
                stopped.await();
                throw th;
            }
        });
    }
}