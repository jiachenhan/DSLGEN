public class foo {
	/**
	 * Dispose associated buffer file and unexport this instance.
	 */
	@Override
	public synchronized void dispose() {
		// must handle concurrent invocations
		if (!disposed) {
			try {
				unexportObject(this, true);
			}
			catch (NoSuchObjectException e) {
				// ignore
			}
			removeOwnerInstance(this);
			removePathInstance(this);
			bufferFile.dispose();
			disposed = true;
		}
	}
}