public class foo {
    /**
     * Extracts the value for logging purpose.
     * <p/>
     * Will clip the value if its too big for logging.
     *
     * @param  obj                the value
     * @param  message            the message
     * @param  allowCachedStreams whether or not cached streams is allowed
     * @param  allowStreams       whether or not streams is allowed
     * @param  allowFiles         whether or not files is allowed (currently not in use)
     * @param  maxChars           limit to maximum number of chars. Use 0 for not limit, and -1 for turning logging
     *                            message body off.
     * @return                    the logging message
     * @see                       org.apache.camel.Exchange#LOG_DEBUG_BODY_MAX_CHARS
     */
    public static String extractValueForLogging(
            Object obj, Message message, boolean allowCachedStreams, boolean allowStreams, boolean allowFiles, int maxChars) {
        if (maxChars < 0) {
            return "[Body is not logged]";
        }

        if (obj == null) {
            return "[Body is null]";
        }

        if (!allowFiles) {
            if (obj instanceof WrappedFile || obj instanceof File) {
                return "[Body is file based: " + obj + "]";
            }
        }

        if (!allowStreams) {
            boolean allow = allowCachedStreams && obj instanceof StreamCache;
            if (!allow) {
                if (obj instanceof StreamCache) {
                    return "[Body is instance of org.apache.camel.StreamCache]";
                } else if (obj instanceof InputStream) {
                    return "[Body is instance of java.io.InputStream]";
                } else if (obj instanceof OutputStream) {
                    return "[Body is instance of java.io.OutputStream]";
                } else if (obj instanceof Reader) {
                    return "[Body is instance of java.io.Reader]";
                } else if (obj instanceof Writer) {
                    return "[Body is instance of java.io.Writer]";
                } else if (obj.getClass().getName().equals("javax.xml.transform.stax.StAXSource")) {
                    // StAX source is streaming based
                    return "[Body is instance of javax.xml.transform.Source]";
                }
            }
        }

        // is the body a stream cache or input stream
        StreamCache cache = null;
        InputStream is = null;
        if (obj instanceof StreamCache) {
            cache = (StreamCache) obj;
        } else if (obj instanceof InputStream) {
            is = (InputStream) obj;
        }

        // grab the message body as a string
        String body = null;
        if (message.getExchange() != null) {
            try {
                body = message.getExchange().getContext().getTypeConverter().tryConvertTo(String.class, message.getExchange(),
                        obj);
            } catch (Throwable e) {
                // ignore as the body is for logging purpose
            }
        }
        if (body == null) {
            try {
                body = obj.toString();
            } catch (Throwable e) {
                // ignore as the body is for logging purpose
            }
        }

        // reset stream cache after use
        if (cache != null) {
            cache.reset();
        } else if (is != null && is.markSupported()) {
            try {
                is.reset();
            } catch (IOException e) {
                // ignore
            }
        }

        if (body == null) {
            return "[Body is null]";
        }

        // clip body if length enabled and the body is too big
        if (maxChars > 0 && body.length() > maxChars) {
            body = body.substring(0, maxChars) + "... [Body clipped after " + maxChars + " chars, total length is "
                   + body.length() + "]";
        }

        return body;
    }
}